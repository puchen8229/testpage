
# ============================================================
# Descriptive analysis and modelling template for USDATA.csv
# 45 US sectors, 1995-2018
# ============================================================

# Install packages if needed:
# install.packages(c("readr","dplyr","tidyr","ggplot2","gganimate",
#                    "ggrepel","scales","forcats","stringr","fixest"))

library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(gganimate)
library(ggrepel)
library(scales)
library(forcats)
library(stringr)
library(fixest)

# ---------- 1. Load data ----------
data_path <- "USDATA.csv"
raw <- read_csv(data_path, show_col_types = FALSE)

if (nrow(raw) != 45 || ncol(raw) != 73) {
  stop("Expected USDATA.csv to have 45 rows and 73 columns (1 index + 72 year columns).")
}

years <- 1995:2018

# The rows are in alphabetical industry order used in the earlier ICIO mapping.
industry_names <- c(
  "Accommodation and food service activities",
  "Activities of households as employers; undifferentiated goods- and services-producing activities of households for own use",
  "Administrative and support services",
  "Agriculture, hunting, forestry",
  "Air transport",
  "Arts, entertainment and recreation",
  "Basic metals",
  "Chemical and chemical products",
  "Coke and refined petroleum products",
  "Computer, electronic and optical equipment",
  "Construction",
  "Education",
  "Electrical equipment",
  "Electricity, gas, steam and air conditioning supply",
  "Fabricated metal products",
  "Financial and insurance activities",
  "Fishing and aquaculture",
  "Food products, beverages and tobacco",
  "Human health and social work activities",
  "IT and other information services",
  "Land transport and transport via pipelines",
  "Machinery and equipment, nec",
  "Manufacturing nec; repair and installation of machinery and equipment",
  "Mining and quarrying, energy producing products",
  "Mining and quarrying, non-energy producing products",
  "Mining support service activities",
  "Motor vehicles, trailers and semi-trailers",
  "Other non-metallic mineral products",
  "Other service activities",
  "Other transport equipment",
  "Paper products and printing",
  "Pharmaceuticals, medicinal chemical and botanical products",
  "Postal and courier activities",
  "Professional, scientific and technical activities",
  "Public administration and defence; compulsory social security",
  "Publishing, audiovisual and broadcasting activities",
  "Real estate activities",
  "Rubber and plastics products",
  "Telecommunications",
  "Textiles, textile products, leather and footwear",
  "Water supply; sewerage, waste management and remediation activities",
  "Water transport",
  "Warehousing and support activities for transportation",
  "Wholesale and retail trade; repair of motor vehicles",
  "Wood and products of wood and cork"
)

raw$industry <- industry_names
raw$sector_id <- paste0("S", sprintf("%02d", seq_len(nrow(raw))))

co2 <- raw[, 2:25]
output_real <- raw[, 26:49]
ppi <- raw[, 50:73]

names(co2) <- years
names(output_real) <- years
names(ppi) <- years

co2$industry <- raw$industry
co2$sector_id <- raw$sector_id
output_real$industry <- raw$industry
output_real$sector_id <- raw$sector_id
ppi$industry <- raw$industry
ppi$sector_id <- raw$sector_id

co2_long <- co2 |>
  pivot_longer(cols = all_of(as.character(years)),
               names_to = "year", values_to = "co2") |>
  mutate(year = as.integer(year))

output_long <- output_real |>
  pivot_longer(cols = all_of(as.character(years)),
               names_to = "year", values_to = "output_real") |>
  mutate(year = as.integer(year))

ppi_long <- ppi |>
  pivot_longer(cols = all_of(as.character(years)),
               names_to = "year", values_to = "ppi") |>
  mutate(year = as.integer(year))

panel <- co2_long |>
  left_join(output_long, by = c("industry","sector_id","year")) |>
  left_join(ppi_long, by = c("industry","sector_id","year")) |>
  mutate(
    co2_intensity = co2 / output_real,
    log_co2 = log(co2),
    log_output = log(output_real),
    log_ppi = log(ppi)
  ) |>
  arrange(industry, year) |>
  group_by(industry) |>
  mutate(
    l1_log_co2 = lag(log_co2),
    l1_log_output = lag(log_output),
    l1_log_ppi = lag(log_ppi),
    dlog_co2 = log_co2 - l1_log_co2,
    dlog_output = log_output - l1_log_output,
    dlog_ppi = log_ppi - l1_log_ppi
  ) |>
  ungroup()

dir.create("co2_outputs", showWarnings = FALSE)

# ---------- 2. Summary tables ----------
annual <- panel |>
  group_by(year) |>
  summarise(
    total_co2 = sum(co2, na.rm = TRUE),
    total_output = sum(output_real, na.rm = TRUE),
    avg_intensity = total_co2 / total_output,
    .groups = "drop"
  )

sector_change <- panel |>
  group_by(industry) |>
  summarise(
    co2_1995 = co2[year == 1995],
    co2_2018 = co2[year == 2018],
    output_1995 = output_real[year == 1995],
    output_2018 = output_real[year == 2018],
    intensity_1995 = co2_intensity[year == 1995],
    intensity_2018 = co2_intensity[year == 2018],
    pct_change_co2 = 100 * (co2_2018 / co2_1995 - 1),
    pct_change_output = 100 * (output_2018 / output_1995 - 1),
    pct_change_intensity = 100 * (intensity_2018 / intensity_1995 - 1),
    abs_change_co2 = co2_2018 - co2_1995,
    .groups = "drop"
  )

write_csv(panel, "co2_outputs/USDATA_long_named.csv")
write_csv(annual, "co2_outputs/co2_annual_summary.csv")
write_csv(sector_change, "co2_outputs/co2_sector_change_1995_2018.csv")

# ---------- 3. Descriptive plots ----------
p_total <- ggplot(annual, aes(year, total_co2)) +
  geom_line(linewidth = 1.1) +
  geom_point(size = 1.8) +
  labs(
    title = "Total CO2 emissions across 45 US sectors, 1995-2018",
    x = NULL, y = "Million metric tons"
  ) +
  theme_minimal(base_size = 13)

ggsave("co2_outputs/co2_total_trend.png", p_total, width = 9, height = 5.5, dpi = 300)

p_output <- ggplot(annual, aes(year, total_output)) +
  geom_line(linewidth = 1.1) +
  geom_point(size = 1.8) +
  labs(
    title = "Total real output across 45 US sectors, 1995-2018",
    x = NULL, y = "Real output"
  ) +
  theme_minimal(base_size = 13)

ggsave("co2_outputs/output_total_trend.png", p_output, width = 9, height = 5.5, dpi = 300)

p_intensity <- ggplot(annual, aes(year, avg_intensity)) +
  geom_line(linewidth = 1.1) +
  geom_point(size = 1.8) +
  labs(
    title = "Aggregate CO2 intensity (CO2 / real output), 1995-2018",
    x = NULL, y = "CO2 per unit of real output"
  ) +
  theme_minimal(base_size = 13)

ggsave("co2_outputs/co2_intensity_trend.png", p_intensity, width = 9, height = 5.5, dpi = 300)

top10_2018 <- panel |>
  filter(year == 2018) |>
  arrange(desc(co2)) |>
  slice(1:10) |>
  pull(industry)

composition <- panel |>
  mutate(group = ifelse(industry %in% top10_2018, industry, "Other 35 sectors")) |>
  group_by(year, group) |>
  summarise(co2 = sum(co2), .groups = "drop") |>
  mutate(group = fct_relevel(group, c(top10_2018, "Other 35 sectors")))

p_comp <- ggplot(composition, aes(year, co2, fill = group)) +
  geom_area() +
  labs(
    title = "Composition of CO2 emissions: top 10 sectors in 2018 plus all others",
    x = NULL, y = "Million metric tons", fill = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "right")

ggsave("co2_outputs/co2_composition_top10plusother.png", p_comp, width = 11, height = 7, dpi = 300)

# Reorder sectors by 2018 emissions for the heatmap
order_2018 <- panel |>
  filter(year == 2018) |>
  arrange(desc(co2)) |>
  pull(industry)

p_heat <- panel |>
  mutate(industry = factor(industry, levels = rev(order_2018))) |>
  ggplot(aes(year, industry, fill = log1p(co2))) +
  geom_tile() +
  scale_fill_viridis_c(name = "log(1 + CO2)") +
  labs(
    title = "Sector CO2 emissions heatmap, ordered by 2018 emissions",
    x = NULL, y = NULL
  ) +
  theme_minimal(base_size = 11)

ggsave("co2_outputs/co2_heatmap_log.png", p_heat, width = 10, height = 12, dpi = 300)

top15_2018 <- panel |>
  filter(year == 2018) |>
  arrange(desc(co2)) |>
  slice(1:15) |>
  pull(industry)

p_slope <- panel |>
  filter(year %in% c(1995, 2018), industry %in% top15_2018) |>
  ggplot(aes(x = factor(year), y = co2, group = industry)) +
  geom_line(linewidth = 0.8, alpha = 0.7) +
  geom_point(size = 2) +
  geom_text_repel(
    data = subset(panel, year == 2018 & industry %in% top15_2018),
    aes(label = str_trunc(industry, 35)),
    direction = "y", hjust = 0, nudge_x = 0.15, size = 3
  ) +
  coord_cartesian(clip = "off") +
  labs(
    title = "Top 15 emitting sectors: 1995 vs 2018",
    x = NULL, y = "Million metric tons"
  ) +
  theme_minimal(base_size = 12) +
  theme(plot.margin = ggplot2::margin(5.5, 120, 5.5, 5.5, unit = "pt"))

ggsave("co2_outputs/co2_top15_slope_1995_2018.png", p_slope, width = 10, height = 7, dpi = 300)

# ---------- 4. Animation ----------
anim_dat <- panel |>
  group_by(year) |>
  slice_max(order_by = co2, n = 12, with_ties = FALSE) |>
  ungroup() |>
  mutate(industry_short = str_trunc(industry, 35))

p_anim <- ggplot(anim_dat, aes(x = co2, y = reorder(industry_short, co2))) +
  geom_col() +
  labs(
    title = "Top 12 emitting sectors in {closest_state}",
    x = "CO2 emissions (million metric tons)", y = NULL
  ) +
  transition_states(year, transition_length = 2, state_length = 1) +
  ease_aes("cubic-in-out") +
  theme_minimal(base_size = 12)

animate(p_anim, width = 900, height = 550, fps = 8,
        renderer = gifski_renderer("co2_outputs/co2_top12_barchart_race.gif"))

# ---------- 5. Recommended econometric model ----------
# Main recommendation: dynamic panel error-correction model (ECM)
# Why?
# - CO2 is persistent
# - output and prices are likely to matter both short-run and long-run
# - sectors are heterogeneous, and year fixed effects absorb common shocks

ecm_data <- panel |>
  filter(!is.na(dlog_co2), !is.na(l1_log_co2), !is.na(l1_log_output), !is.na(l1_log_ppi))

# Error-correction style dynamic panel:
# Δlog(CO2_it) = α_i + τ_t + φ1 log(CO2_i,t-1) + φ2 log(Output_i,t-1)
#              + φ3 log(PPI_i,t-1) + β1 Δlog(Output_it) + β2 Δlog(PPI_it) + u_it
#
# If φ1 < 0 and the lagged levels are jointly significant, that supports
# long-run adjustment plus short-run effects.

model_ecm <- feols(
  dlog_co2 ~ l1_log_co2 + l1_log_output + l1_log_ppi + dlog_output + dlog_ppi | industry + year,
  data = ecm_data,
  vcov = ~ industry + year
)

# Simpler dynamic levels model (useful baseline):
model_dynamic_fe <- feols(
  log_co2 ~ l1_log_co2 + log_output + log_ppi | industry + year,
  data = panel |> filter(!is.na(l1_log_co2)),
  vcov = ~ industry + year
)

sink("co2_outputs/model_summaries.txt")
cat("=== Dynamic panel ECM ===\n")
print(summary(model_ecm))
cat("\n\n=== Dynamic FE in levels ===\n")
print(summary(model_dynamic_fe))
sink()


# For forecasting, use rolling-origin validation rather than a simple random split
# when year fixed effects are included. A practical workflow is:
# 1. Refit the ECM recursively up to year t
# 2. Predict year t+1
# 3. Compare against benchmarks such as a random walk or AR(1)
# 4. If out-of-sample forecasting is the main objective, replace year FE with
#    a low-dimensional common-factor or trend specification.

cat("All outputs written to folder: co2_outputs/\n")

