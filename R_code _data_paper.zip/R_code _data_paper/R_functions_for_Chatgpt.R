#### R functions for Chatgpt
# simulate_common_beta_vecm()
# dgp_K2_r1()
# dgp_K3_r2()
# estimate_break_vecm_rrr()
# estimate_separate_vecms_rrr()
# estimate_common_beta_vecm()
# estimate_separate_vecms()
# run_common_space_mc()
#
#


### RRR test of common beta

# ============================================================
# Utility functions
# ============================================================

# Residualise every column of X on Z
residualise <- function(X, Z = NULL) {
  
  X <- as.matrix(X)
  
  if (is.null(Z) || ncol(Z) == 0L)
    return(X)
  
  Z <- as.matrix(Z)
  qrz <- qr(Z, tol = 1e-10)
  
  X - qr.fitted(qrz, X)
}


# Symmetric inverse of a positive-definite matrix
symmetric_inverse <- function(A, tolerance = 1e-10) {
  
  A <- (A + t(A)) / 2
  ee <- eigen(A, symmetric = TRUE)
  
  cutoff <- tolerance * max(ee$values)
  
  if (any(ee$values <= cutoff))
    stop("Matrix is numerically singular.")
  
  ee$vectors %*%
    diag(1 / ee$values, nrow = length(ee$values)) %*%
    t(ee$vectors)
}


# Symmetric inverse square root
inverse_square_root <- function(A, tolerance = 1e-10) {
  
  A <- (A + t(A)) / 2
  ee <- eigen(A, symmetric = TRUE)
  
  cutoff <- tolerance * max(ee$values)
  
  if (any(ee$values <= cutoff))
    stop("Matrix is numerically singular.")
  
  ee$vectors %*%
    diag(1 / sqrt(ee$values), nrow = length(ee$values)) %*%
    t(ee$vectors)
}


# Normalise beta so beta[norm_rows, ] = I_r
normalise_beta <- function(beta, norm_rows) {
  
  beta <- as.matrix(beta)
  r <- ncol(beta)
  
  if (length(norm_rows) != r)
    stop("norm_rows must contain rank row numbers.")
  
  normalization_block <- beta[norm_rows, , drop = FALSE]
  
  if (abs(det(normalization_block)) < 1e-10)
    stop("The selected norm_rows do not identify beta.")
  
  beta %*% solve(normalization_block)
}


# Gaussian log likelihood from a residual matrix
gaussian_loglik <- function(residuals) {
  
  residuals <- as.matrix(residuals)
  
  n <- nrow(residuals)
  K <- ncol(residuals)
  
  # ML covariance estimator
  Omega <- crossprod(residuals) / n
  
  logdet <- determinant(
    Omega,
    logarithm = TRUE
  )
  
  if (logdet$sign <= 0)
    stop("Residual covariance matrix is not positive definite.")
  
  log_likelihood <- -0.5 * n * (
    K * (1 + log(2 * pi)) +
      as.numeric(logdet$modulus)
  )
  
  list(
    logLik = log_likelihood,
    Omega = Omega
  )
}



construct_vecm_matrices <- function(
    Y,
    break_t,
    lag_level = 2,
    include_intercept = TRUE) {
  
  Y <- as.matrix(Y)
  storage.mode(Y) <- "double"
  
  TT <- nrow(Y)
  K  <- ncol(Y)
  p  <- lag_level
  
  if (break_t <= p || break_t > TT)
    stop("Invalid break point.")
  
  # Usable equation dates
  equation_times <- (p + 1L):TT
  
  # diff(Y)[j, ] corresponds to Delta Y_(j+1)
  DYall <- diff(Y)
  
  # Dependent stationary variable Delta Y_t
  X0 <- Y[equation_times, , drop = FALSE] -
    Y[equation_times - 1L, , drop = FALSE]
  
  # Lagged I(1) variable Y_(t-1)
  X1 <- Y[equation_times - 1L, , drop = FALSE]
  
  # Short-run regressors:
  # Delta Y_(t-1), ..., Delta Y_(t-p+1)
  if (p > 1L) {
    
    short_run_blocks <- lapply(seq_len(p - 1L), function(j) {
      
      DYall[
        equation_times - 1L - j,
        ,
        drop = FALSE
      ]
    })
    
    Z <- do.call(cbind, short_run_blocks)
    
  } else {
    
    Z <- matrix(
      numeric(0),
      nrow = length(equation_times),
      ncol = 0
    )
  }
  
  if (include_intercept)
    Z <- cbind(Z, intercept = 1)
  
  # t = break_t is assigned to regime 2
  regime <- ifelse(
    equation_times < break_t,
    1L,
    2L
  )
  
  list(
    Y = Y,
    X0 = X0,
    X1 = X1,
    Z = Z,
    regime = regime,
    equation_times = equation_times,
    K = K,
    lag_level = p,
    break_t = break_t,
    include_intercept = include_intercept
  )
}



rrr_beta <- function(
    R0,
    R1,
    rank,
    norm_rows,
    tolerance = 1e-10) {
  
  R0 <- as.matrix(R0)
  R1 <- as.matrix(R1)
  
  n <- nrow(R0)
  K <- ncol(R1)
  r <- rank
  
  if (nrow(R1) != n)
    stop("R0 and R1 must have the same number of rows.")
  
  if (r >= K)
    stop("rank must be smaller than the number of variables.")
  
  S00 <- crossprod(R0) / n
  S11 <- crossprod(R1) / n
  S10 <- crossprod(R1, R0) / n
  S01 <- t(S10)
  
  S00_inverse <- symmetric_inverse(
    S00,
    tolerance = tolerance
  )
  
  # Matrix on the right-hand side of the
  # generalized eigenvalue problem
  A <- S10 %*% S00_inverse %*% S01
  A <- (A + t(A)) / 2
  
  # Convert the generalized eigenvalue problem to an
  # ordinary symmetric eigenvalue problem
  S11_inverse_half <- inverse_square_root(
    S11,
    tolerance = tolerance
  )
  
  M <- S11_inverse_half %*%
    A %*%
    S11_inverse_half
  
  M <- (M + t(M)) / 2
  
  eig <- eigen(M, symmetric = TRUE)
  
  ordering <- order(
    eig$values,
    decreasing = TRUE
  )
  
  eigenvalues <- eig$values[ordering]
  eigenvectors <- eig$vectors[, ordering, drop = FALSE]
  
  # Generalized eigenvectors belonging to the I(1) side
  beta_raw <- S11_inverse_half %*%
    eigenvectors[, seq_len(r), drop = FALSE]
  
  beta <- normalise_beta(
    beta_raw,
    norm_rows = norm_rows
  )
  
  list(
    beta = beta,
    beta_raw = beta_raw,
    eigenvalues = eigenvalues,
    canonical_correlations = sqrt(pmax(eigenvalues, 0)),
    S00 = S00,
    S11 = S11,
    S10 = S10
  )
}






simulate_common_beta_vecm <- function(
    T = 300,
    beta,
    alpha_1,
    alpha_2,
    Gamma_1,
    Gamma_2,
    Omega,
    break_t = floor(T / 2) + 1L,
    intercept_1 = NULL,
    intercept_2 = NULL,
    burn_in = 200,
    initial_value = NULL,
    seed = NULL) {
  
  if (!is.null(seed))
    set.seed(seed)
  
  beta    <- as.matrix(beta)
  alpha_1 <- as.matrix(alpha_1)
  alpha_2 <- as.matrix(alpha_2)
  Gamma_1 <- as.matrix(Gamma_1)
  Gamma_2 <- as.matrix(Gamma_2)
  Omega   <- as.matrix(Omega)
  
  K <- nrow(beta)
  r <- ncol(beta)
  
  stopifnot(
    all(dim(alpha_1) == c(K, r)),
    all(dim(alpha_2) == c(K, r)),
    all(dim(Gamma_1) == c(K, K)),
    all(dim(Gamma_2) == c(K, K)),
    all(dim(Omega) == c(K, K))
  )
  
  if (is.null(intercept_1))
    intercept_1 <- rep(0, K)
  
  if (is.null(intercept_2))
    intercept_2 <- rep(0, K)
  
  total_T <- T + burn_in
  
  Y  <- matrix(0, nrow = total_T, ncol = K)
  DY <- matrix(0, nrow = total_T, ncol = K)
  
  if (!is.null(initial_value))
    Y[1, ] <- initial_value
  
  chol_Omega <- chol(Omega)
  
  innovations <- matrix(
    rnorm(total_T * K),
    nrow = total_T,
    ncol = K
  ) %*% chol_Omega
  
  # Put the break at the corresponding point in the
  # retained sample
  break_total <- burn_in + break_t
  
  for (t in 2:total_T) {
    
    if (t < break_total) {
      
      alpha_t <- alpha_1
      Gamma_t <- Gamma_1
      c_t     <- intercept_1
      
    } else {
      
      alpha_t <- alpha_2
      Gamma_t <- Gamma_2
      c_t     <- intercept_2
    }
    
    error_correction <- drop(
      crossprod(beta, Y[t - 1L, ])
    )
    
    DY[t, ] <- c_t +
      drop(alpha_t %*% error_correction) +
      drop(Gamma_t %*% DY[t - 1L, ]) +
      innovations[t, ]
    
    Y[t, ] <- Y[t - 1L, ] + DY[t, ]
  }
  
  keep <- (burn_in + 1L):(burn_in + T)
  
  Y_out <- Y[keep, , drop = FALSE]
  DY_out <- DY[keep, , drop = FALSE]
  
  colnames(Y_out) <- paste0("y", seq_len(K))
  colnames(DY_out) <- paste0("dy", seq_len(K))
  
  list(
    Y = Y_out,
    DY = DY_out,
    beta = beta,
    alpha_1 = alpha_1,
    alpha_2 = alpha_2,
    Gamma_1 = Gamma_1,
    Gamma_2 = Gamma_2,
    Omega = Omega,
    break_t = break_t,
    rank = r,
    K = K
  )
}




dgp_K2_r1 <- function(
    T = 300,
    break_t = floor(T / 2) + 1L,
    seed = NULL) {
  
  beta <- matrix(
    c(1, -1),
    nrow = 2,
    ncol = 1
  )
  
  alpha_1 <- matrix(
    c(-0.15, 0.15),
    nrow = 2,
    ncol = 1
  )
  
  alpha_2 <- matrix(
    c(-0.25, 0.25),
    nrow = 2,
    ncol = 1
  )
  
  Gamma_1 <- matrix(
    c(
      0.15, 0.00,
      0.00, 0.10
    ),
    nrow = 2,
    byrow = TRUE
  )
  
  Gamma_2 <- matrix(
    c(
      -0.05, 0.05,
      0.05, 0.20
    ),
    nrow = 2,
    byrow = TRUE
  )
  
  Omega <- matrix(
    c(
      1.00, 0.20,
      0.20, 1.00
    ),
    nrow = 2,
    byrow = TRUE
  )
  
  simulate_common_beta_vecm(
    T = T,
    beta = beta,
    alpha_1 = alpha_1,
    alpha_2 = alpha_2,
    Gamma_1 = Gamma_1,
    Gamma_2 = Gamma_2,
    Omega = Omega,
    break_t = break_t,
    burn_in = 200,
    seed = seed
  )
}



sim <- dgp_K2_r1(
  T = 300,
  seed = 123
)




dgp_K3_r2 <- function(
    T = 300,
    break_t = floor(T / 2) + 1L,
    seed = NULL,
    burn_in = 200) {
  
  # Three variables and two cointegrating relations
  K <- 3
  r <- 2
  
  # ----------------------------------------------------------
  # Common cointegrating matrix
  #
  # EC1_t = y1_t - y3_t
  # EC2_t = y2_t - y3_t
  # ----------------------------------------------------------
  
  beta <- matrix(
    c(
      1,  0,
      0,  1,
      -1, -1
    ),
    nrow = K,
    ncol = r,
    byrow = TRUE
  )
  
  rownames(beta) <- paste0("y", 1:K)
  colnames(beta) <- paste0("beta", 1:r)
  
  # ----------------------------------------------------------
  # Regime-specific adjustment coefficients
  #
  # Construction ensures:
  # beta' alpha_s = -kappa_s I_r
  # ----------------------------------------------------------
  
  alpha_1 <- -0.20 *
    beta %*% solve(crossprod(beta))
  
  alpha_2 <- -0.35 *
    beta %*% solve(crossprod(beta))
  
  rownames(alpha_1) <- paste0("y", 1:K)
  rownames(alpha_2) <- paste0("y", 1:K)
  
  colnames(alpha_1) <- paste0("EC", 1:r)
  colnames(alpha_2) <- paste0("EC", 1:r)
  
  # ----------------------------------------------------------
  # Regime-specific short-run dynamics
  # ----------------------------------------------------------
  
  Gamma_1 <- matrix(
    c(
      0.15, 0.00, 0.00,
      0.00, 0.10, 0.00,
      0.00, 0.00, 0.12
    ),
    nrow = K,
    ncol = K,
    byrow = TRUE
  )
  
  Gamma_2 <- matrix(
    c(
      -0.05, 0.04, 0.00,
      0.03, 0.18, 0.02,
      0.00, 0.04, 0.10
    ),
    nrow = K,
    ncol = K,
    byrow = TRUE
  )
  
  rownames(Gamma_1) <- colnames(Gamma_1) <-
    paste0("y", 1:K)
  
  rownames(Gamma_2) <- colnames(Gamma_2) <-
    paste0("y", 1:K)
  
  # ----------------------------------------------------------
  # Common innovation covariance
  # ----------------------------------------------------------
  
  Omega <- matrix(
    c(
      1.00, 0.20, 0.10,
      0.20, 1.00, 0.15,
      0.10, 0.15, 1.00
    ),
    nrow = K,
    ncol = K,
    byrow = TRUE
  )
  
  rownames(Omega) <- colnames(Omega) <-
    paste0("y", 1:K)
  
  # ----------------------------------------------------------
  # Generate the VECM
  # ----------------------------------------------------------
  
  simulation <- simulate_common_beta_vecm(
    T = T,
    beta = beta,
    alpha_1 = alpha_1,
    alpha_2 = alpha_2,
    Gamma_1 = Gamma_1,
    Gamma_2 = Gamma_2,
    Omega = Omega,
    break_t = break_t,
    intercept_1 = rep(0, K),
    intercept_2 = rep(0, K),
    burn_in = burn_in,
    seed = seed
  )
  
  simulation$DGP <- "K3_r2"
  simulation$degrees_freedom <- r * (K - r)
  
  simulation
}

sim_K3_r2 <- dgp_K3_r2(
  T = 300,
  break_t = 151,
  seed = 123
)



estimate_break_vecm_rrr <- function(
    Y,
    break_t,
    rank,
    lag_level = 2,
    norm_rows = seq_len(rank),
    include_intercept = TRUE,
    tolerance = 1e-10) {
  
  data <- construct_vecm_matrices(
    Y = Y,
    break_t = break_t,
    lag_level = lag_level,
    include_intercept = include_intercept
  )
  
  X0 <- data$X0
  X1 <- data$X1
  Z  <- data$Z
  
  regime <- data$regime
  K <- data$K
  p <- data$lag_level
  r <- rank
  n <- nrow(X0)
  
  D1 <- as.numeric(regime == 1L)
  D2 <- as.numeric(regime == 2L)
  
  # ----------------------------------------------------------
  # Expanded stationary matrix
  #
  # X0_star = [D1 Delta Y, D2 Delta Y]
  # ----------------------------------------------------------
  
  X0_star <- cbind(
    D1 * X0,
    D2 * X0
  )
  
  # Regime-specific short-run regressors
  Z_star <- cbind(
    D1 * Z,
    D2 * Z
  )
  
  # Partial out regime-specific short-run dynamics
  R0_star <- residualise(X0_star, Z_star)
  R1      <- residualise(X1, Z_star)
  
  # Block RRR: common beta
  common_rrr <- rrr_beta(
    R0 = R0_star,
    R1 = R1,
    rank = r,
    norm_rows = norm_rows,
    tolerance = tolerance
  )
  
  beta <- common_rrr$beta
  
  # ----------------------------------------------------------
  # Conditional estimation of alpha_s, Gamma_s and c_s
  # ----------------------------------------------------------
  
  fit_regime <- function(s) {
    
    index <- which(regime == s)
    
    X0_s <- X0[index, , drop = FALSE]
    X1_s <- X1[index, , drop = FALSE]
    Z_s  <- Z[index, , drop = FALSE]
    
    EC_s <- X1_s %*% beta
    
    # Delta Y_t = alpha_s beta'Y_(t-1) + B_s Z_t + error
    X_s <- cbind(EC_s, Z_s)
    
    coefficients <- qr.solve(
      X_s,
      X0_s,
      tol = tolerance
    )
    
    residuals <- X0_s - X_s %*% coefficients
    
    likelihood <- gaussian_loglik(residuals)
    
    alpha <- t(
      coefficients[seq_len(r), , drop = FALSE]
    )
    
    Gamma <- vector("list", max(p - 1L, 0L))
    
    if (p > 1L) {
      
      for (j in seq_len(p - 1L)) {
        
        coefficient_rows <-
          r + ((j - 1L) * K + 1L):(j * K)
        
        Gamma[[j]] <- t(
          coefficients[
            coefficient_rows,
            ,
            drop = FALSE
          ]
        )
      }
    }
    
    intercept <- if (include_intercept) {
      
      drop(coefficients[nrow(coefficients), ])
      
    } else {
      
      rep(0, K)
    }
    
    list(
      regime = s,
      equation_times = data$equation_times[index],
      nobs = length(index),
      beta = beta,
      alpha = alpha,
      Gamma = Gamma,
      intercept = intercept,
      Omega = likelihood$Omega,
      residuals = residuals,
      logLik = likelihood$logLik
    )
  }
  
  regime_1_fit <- fit_regime(1L)
  regime_2_fit <- fit_regime(2L)
  
  LH <- regime_1_fit$logLik +
    regime_2_fit$logLik
  
  result <- list(
    beta = beta,
    alpha_1 = regime_1_fit$alpha,
    alpha_2 = regime_2_fit$alpha,
    Gamma_1 = regime_1_fit$Gamma,
    Gamma_2 = regime_2_fit$Gamma,
    intercept_1 = regime_1_fit$intercept,
    intercept_2 = regime_2_fit$intercept,
    Omega_1 = regime_1_fit$Omega,
    Omega_2 = regime_2_fit$Omega,
    residuals_1 = regime_1_fit$residuals,
    residuals_2 = regime_2_fit$residuals,
    regime_1 = regime_1_fit,
    regime_2 = regime_2_fit,
    logLik = LH,
    rrr = common_rrr,
    equation_times = data$equation_times,
    regime = regime,
    break_t = break_t,
    rank = r,
    lag_level = p,
    norm_rows = norm_rows,
    method = "Block reduced-rank regression"
  )
  
  class(result) <- "break_vecm_rrr"
  
  result
}


logLik.break_vecm_rrr <- function(object, ...) {
  
  structure(
    object$logLik,
    class = "logLik",
    nobs = length(object$equation_times)
  )
}



estimate_separate_vecms_rrr <- function(
    Y,
    break_t,
    rank,
    lag_level = 2,
    norm_rows_1 = seq_len(rank),
    norm_rows_2 = seq_len(rank),
    include_intercept = TRUE,
    tolerance = 1e-10) {
  
  data <- construct_vecm_matrices(
    Y = Y,
    break_t = break_t,
    lag_level = lag_level,
    include_intercept = include_intercept
  )
  
  index_1 <- which(data$regime == 1L)
  index_2 <- which(data$regime == 2L)
  
  regime_1 <- estimate_one_vecm_rrr(
    X0 = data$X0[index_1, , drop = FALSE],
    X1 = data$X1[index_1, , drop = FALSE],
    Z  = data$Z[index_1, , drop = FALSE],
    equation_times = data$equation_times[index_1],
    rank = rank,
    lag_level = lag_level,
    norm_rows = norm_rows_1,
    include_intercept = include_intercept,
    tolerance = tolerance
  )
  
  regime_2 <- estimate_one_vecm_rrr(
    X0 = data$X0[index_2, , drop = FALSE],
    X1 = data$X1[index_2, , drop = FALSE],
    Z  = data$Z[index_2, , drop = FALSE],
    equation_times = data$equation_times[index_2],
    rank = rank,
    lag_level = lag_level,
    norm_rows = norm_rows_2,
    include_intercept = include_intercept,
    tolerance = tolerance
  )
  
  result <- list(
    regime_1 = regime_1,
    regime_2 = regime_2,
    logLik_1 = regime_1$logLik,
    logLik_2 = regime_2$logLik,
    logLik = regime_1$logLik + regime_2$logLik,
    break_t = break_t,
    rank = rank,
    lag_level = lag_level,
    method = "Separate Johansen reduced-rank regressions"
  )
  
  class(result) <- "separate_vecms_rrr"
  
  result
}


logLik.separate_vecms_rrr <- function(object, ...) {
  
  structure(
    object$logLik,
    class = "logLik",
    nobs = object$regime_1$nobs + object$regime_2$nobs
  )
}









run_common_space_mc <- function(
    dgp = c("K2_r1", "K3_r2"),
    R = 1000,
    T = 300,
    lag_level = 2,
    include_intercept = FALSE,
    seed = 20260714,
    output_directory = ".",
    progress_every = 50,
    save_results = TRUE,
    make_plots = TRUE) {
  
  dgp <- match.arg(dgp)
  
  # ----------------------------------------------------------
  # Select the DGP and corresponding model dimensions
  # ----------------------------------------------------------
  
  if (dgp == "K2_r1") {
    
    dgp_function <- dgp_K2_r1
    
    K <- 2
    rank <- 1
    norm_rows <- 1
    
  } else if (dgp == "K3_r2") {
    
    dgp_function <- dgp_K3_r2
    
    K <- 3
    rank <- 2
    norm_rows <- c(1, 2)
  }
  
  degrees_freedom <- rank * (K - rank)
  
  if (!dir.exists(output_directory)) {
    dir.create(
      output_directory,
      recursive = TRUE
    )
  }
  
  # Reproducible replication-specific seeds
  set.seed(seed)
  
  replication_seeds <- sample.int(
    .Machine$integer.max,
    size = R,
    replace = FALSE
  )
  
  # ----------------------------------------------------------
  # Storage
  # ----------------------------------------------------------
  
  results <- data.frame(
    replication = seq_len(R),
    seed = replication_seeds,
    LH_common = NA_real_,
    LH_regime_1 = NA_real_,
    LH_regime_2 = NA_real_,
    LH_separate = NA_real_,
    LR = NA_real_,
    successful = FALSE,
    error_message = NA_character_,
    stringsAsFactors = FALSE
  )
  
  start_time <- proc.time()[["elapsed"]]
  
  # ----------------------------------------------------------
  # Monte Carlo loop
  # ----------------------------------------------------------
  
  for (b in seq_len(R)) {
    
    one_result <- tryCatch({
      
      # Generate data under the common-beta null
      simulated_data <- dgp_function(
        T = T,
        break_t = floor(T / 2) + 1L,
        seed = replication_seeds[b]
      )
      
      Y <- simulated_data$Y
      break_t <- simulated_data$break_t
      
      # Restricted model: common beta
      common_fit <- fit_common_rrr(
        Y = Y,
        break_t = break_t,
        rank = rank,
        lag_level = lag_level,
        norm_rows = norm_rows,
        include_intercept = include_intercept
      )
      
      # Unrestricted model: separate beta_1 and beta_2
      separate_fit <- fit_separate_rrr(
        Y = Y,
        break_t = break_t,
        rank = rank,
        lag_level = lag_level,
        norm_rows_1 = norm_rows,
        norm_rows_2 = norm_rows,
        include_intercept = include_intercept
      )
      
      LH_common <- extract_common_loglik(common_fit)
      
      separate_loglik <- extract_separate_loglik(
        separate_fit
      )
      
      LH1 <- separate_loglik["LH1"]
      LH2 <- separate_loglik["LH2"]
      
      LH_separate <- LH1 + LH2
      
      LR <- 2 * (
        LH_separate - LH_common
      )
      
      if (!all(is.finite(
        c(LH_common, LH1, LH2, LR)
      ))) {
        stop("At least one likelihood or LR statistic is non-finite.")
      }
      
      list(
        successful = TRUE,
        LH_common = LH_common,
        LH1 = LH1,
        LH2 = LH2,
        LH_separate = LH_separate,
        LR = LR,
        error_message = NA_character_
      )
      
    }, error = function(e) {
      
      list(
        successful = FALSE,
        LH_common = NA_real_,
        LH1 = NA_real_,
        LH2 = NA_real_,
        LH_separate = NA_real_,
        LR = NA_real_,
        error_message = conditionMessage(e)
      )
    })
    
    results$successful[b] <- one_result$successful
    results$LH_common[b] <- one_result$LH_common
    results$LH_regime_1[b] <- one_result$LH1
    results$LH_regime_2[b] <- one_result$LH2
    results$LH_separate[b] <- one_result$LH_separate
    results$LR[b] <- one_result$LR
    results$error_message[b] <- one_result$error_message
    
    if (b %% progress_every == 0L || b == R) {
      
      elapsed <- proc.time()[["elapsed"]] - start_time
      success_count <- sum(results$successful[seq_len(b)])
      
      message(
        sprintf(
          paste0(
            "DGP %s: completed %d/%d; ",
            "successful = %d; elapsed = %.1f seconds"
          ),
          dgp,
          b,
          R,
          success_count,
          elapsed
        )
      )
    }
  }
  
  elapsed_time <- proc.time()[["elapsed"]] - start_time
  
  # ----------------------------------------------------------
  # Retain successful statistics
  # ----------------------------------------------------------
  
  valid_LR <- results$LR[
    results$successful &
      is.finite(results$LR)
  ]
  
  number_successful <- length(valid_LR)
  number_failed <- R - number_successful
  
  if (number_successful < 10L) {
    stop("Too few successful replications.")
  }
  
  # ----------------------------------------------------------
  # Empirical distribution summary
  # ----------------------------------------------------------
  
  probabilities <- c(
    0.01, 0.025, 0.05, 0.10,
    0.25, 0.50, 0.75,
    0.90, 0.95, 0.975, 0.99
  )
  
  empirical_quantiles <- quantile(
    valid_LR,
    probs = probabilities,
    names = FALSE
  )
  
  chi_square_quantiles <- qchisq(
    probabilities,
    df = degrees_freedom
  )
  
  quantile_comparison <- data.frame(
    probability = probabilities,
    empirical_LR = empirical_quantiles,
    chi_square = chi_square_quantiles,
    difference = empirical_quantiles -
      chi_square_quantiles
  )
  
  nominal_levels <- c(0.10, 0.05, 0.01)
  
  chi_square_critical_values <- qchisq(
    1 - nominal_levels,
    df = degrees_freedom
  )
  
  empirical_rejection_rates <- vapply(
    chi_square_critical_values,
    function(critical_value) {
      mean(valid_LR > critical_value)
    },
    numeric(1)
  )
  
  rejection_comparison <- data.frame(
    nominal_level = nominal_levels,
    chi_square_critical_value =
      chi_square_critical_values,
    empirical_rejection_rate =
      empirical_rejection_rates,
    rejection_rate_MCSE = sqrt(
      empirical_rejection_rates *
        (1 - empirical_rejection_rates) /
        number_successful
    )
  )
  
  ks_test <- tryCatch(
    ks.test(
      valid_LR,
      "pchisq",
      df = degrees_freedom
    ),
    error = function(e) NULL
  )
  
  summary_results <- data.frame(
    DGP = dgp,
    K = K,
    rank = rank,
    degrees_freedom = degrees_freedom,
    sample_size = T,
    break_t = floor(T / 2) + 1L,
    requested_replications = R,
    successful_replications = number_successful,
    failed_replications = number_failed,
    mean_LR = mean(valid_LR),
    chi_square_mean = degrees_freedom,
    variance_LR = var(valid_LR),
    chi_square_variance = 2 * degrees_freedom,
    median_LR = median(valid_LR),
    minimum_LR = min(valid_LR),
    maximum_LR = max(valid_LR),
    negative_LR_frequency = mean(valid_LR < 0),
    empirical_90 = unname(
      quantile(valid_LR, 0.90)
    ),
    chi_square_90 = qchisq(
      0.90,
      degrees_freedom
    ),
    empirical_95 = unname(
      quantile(valid_LR, 0.95)
    ),
    chi_square_95 = qchisq(
      0.95,
      degrees_freedom
    ),
    empirical_99 = unname(
      quantile(valid_LR, 0.99)
    ),
    chi_square_99 = qchisq(
      0.99,
      degrees_freedom
    ),
    KS_statistic = if (is.null(ks_test)) {
      NA_real_
    } else {
      unname(ks_test$statistic)
    },
    KS_p_value = if (is.null(ks_test)) {
      NA_real_
    } else {
      ks_test$p.value
    },
    elapsed_seconds = elapsed_time
  )
  
  # ----------------------------------------------------------
  # Save results
  # ----------------------------------------------------------
  
  file_prefix <- paste0(
    "common_space_MC_",
    dgp,
    "_T",
    T,
    "_R",
    R
  )
  
  if (save_results) {
    
    # Full replication-level results
    write.csv(
      results,
      file = file.path(
        output_directory,
        paste0(file_prefix, "_full_results.csv")
      ),
      row.names = FALSE
    )
    
    # LR values only, one number per line
    write.table(
      valid_LR,
      file = file.path(
        output_directory,
        paste0(file_prefix, "_LR.txt")
      ),
      row.names = FALSE,
      col.names = FALSE,
      quote = FALSE
    )
    
    write.csv(
      summary_results,
      file = file.path(
        output_directory,
        paste0(file_prefix, "_summary.csv")
      ),
      row.names = FALSE
    )
    
    write.csv(
      quantile_comparison,
      file = file.path(
        output_directory,
        paste0(file_prefix, "_quantiles.csv")
      ),
      row.names = FALSE
    )
    
    write.csv(
      rejection_comparison,
      file = file.path(
        output_directory,
        paste0(file_prefix, "_rejection_rates.csv")
      ),
      row.names = FALSE
    )
  }
  
  # ----------------------------------------------------------
  # Distribution comparison plots
  # ----------------------------------------------------------
  
  if (make_plots) {
    
    png_file <- file.path(
      output_directory,
      paste0(file_prefix, "_distribution.png")
    )
    
    png(
      filename = png_file,
      width = 1800,
      height = 800,
      res = 150
    )
    
    par(
      mfrow = c(1, 2),
      mar = c(4.5, 4.5, 3.5, 1)
    )
    
    # Histogram and chi-square density
    hist(
      valid_LR,
      breaks = "FD",
      probability = TRUE,
      col = "lightsteelblue",
      border = "white",
      main = paste0(
        dgp,
        ": empirical distribution"
      ),
      xlab = "Common-space statistic",
      ylab = "Density"
    )
    
    curve(
      dchisq(
        x,
        df = degrees_freedom
      ),
      from = 0,
      to = max(valid_LR),
      add = TRUE,
      col = "firebrick",
      lwd = 3,
      n = 1000
    )
    
    abline(
      v = qchisq(
        0.95,
        degrees_freedom
      ),
      col = "firebrick",
      lty = 2,
      lwd = 2
    )
    
    abline(
      v = quantile(
        valid_LR,
        0.95
      ),
      col = "navy",
      lty = 2,
      lwd = 2
    )
    
    legend(
      "topright",
      legend = c(
        "Simulated statistic",
        paste0(
          expression(chi^2),
          "(", degrees_freedom, ")"
        ),
        "Chi-square 95%",
        "Empirical 95%"
      ),
      col = c(
        "lightsteelblue",
        "firebrick",
        "firebrick",
        "navy"
      ),
      lwd = c(8, 3, 2, 2),
      lty = c(1, 1, 2, 2),
      bty = "n"
    )
    
    # Quantile-quantile comparison
    qq_probabilities <- seq(
      0.01,
      0.99,
      by = 0.01
    )
    
    theoretical_quantiles <- qchisq(
      qq_probabilities,
      df = degrees_freedom
    )
    
    empirical_qq <- quantile(
      valid_LR,
      probs = qq_probabilities,
      names = FALSE
    )
    
    plot(
      theoretical_quantiles,
      empirical_qq,
      pch = 16,
      cex = 0.7,
      col = "navy",
      xlab = paste0(
        "Theoretical chi-square(",
        degrees_freedom,
        ") quantiles"
      ),
      ylab = "Empirical LR quantiles",
      main = "Chi-square Q-Q plot"
    )
    
    maximum_quantile <- max(
      theoretical_quantiles,
      empirical_qq
    )
    
    abline(
      a = 0,
      b = 1,
      col = "firebrick",
      lwd = 2
    )
    
    dev.off()
  }
  
  # ----------------------------------------------------------
  # Print concise results
  # ----------------------------------------------------------
  
  cat("\n")
  cat("====================================================\n")
  cat("Common cointegration-space Monte Carlo experiment\n")
  cat("====================================================\n")
  cat("DGP:                  ", dgp, "\n")
  cat("K:                    ", K, "\n")
  cat("Rank:                 ", rank, "\n")
  cat("Chi-square df:         ", degrees_freedom, "\n")
  cat("Sample size:           ", T, "\n")
  cat("Break point:           ", floor(T / 2) + 1L, "\n")
  cat("Successful runs:       ", number_successful, "\n")
  cat("Failed runs:           ", number_failed, "\n")
  cat("Mean LR:               ", mean(valid_LR), "\n")
  cat("Chi-square mean:       ", degrees_freedom, "\n")
  cat("Variance LR:           ", var(valid_LR), "\n")
  cat("Chi-square variance:   ", 2 * degrees_freedom, "\n")
  cat("Empirical 95% value:  ",
      quantile(valid_LR, 0.95), "\n")
  cat("Chi-square 95% value: ",
      qchisq(0.95, degrees_freedom), "\n")
  cat("Negative frequency:   ",
      mean(valid_LR < 0), "\n")
  cat("\nEmpirical rejection rates using chi-square values:\n")
  print(rejection_comparison)
  cat("====================================================\n")
  
  invisible(
    list(
      LR = valid_LR,
      full_results = results,
      summary = summary_results,
      quantiles = quantile_comparison,
      rejection_rates = rejection_comparison,
      KS_test = ks_test,
      settings = list(
        dgp = dgp,
        K = K,
        rank = rank,
        df = degrees_freedom,
        T = T,
        R = R,
        lag_level = lag_level,
        norm_rows = norm_rows,
        seed = seed
      )
    )
  )
}





estimate_common_beta_vecm <- function(
    Y,
    break_t,
    rank,
    lag_level = 2,
    norm_rows = seq_len(rank),
    beta_start = NULL,
    covariance = c("separate", "common"),
    include_intercept = TRUE,
    n_starts = 10,
    seed = 123,
    maxit = 3000,
    reltol = 1e-10) {
  
  covariance <- match.arg(covariance)
  
  Y <- as.matrix(Y)
  storage.mode(Y) <- "double"
  
  TT <- nrow(Y)
  K  <- ncol(Y)
  r  <- rank
  p  <- lag_level
  
  if (r >= K)
    stop("rank must be smaller than the number of variables.")
  
  if (length(norm_rows) != r ||
      length(unique(norm_rows)) != r ||
      any(!norm_rows %in% seq_len(K))) {
    stop("norm_rows must contain r distinct row numbers.")
  }
  
  if (break_t <= p || break_t > TT)
    stop("Invalid break point.")
  
  # ------------------------------------------------------------
  # Construct the VECM sample
  #
  # If p = 2:
  # Delta y_t = alpha beta'y_(t-1) + Gamma_1 Delta y_(t-1) + e_t
  # ------------------------------------------------------------
  
  equation_times <- (p + 1L):TT
  
  DY <- diff(Y)
  
  Ydep <- Y[equation_times, , drop = FALSE] -
    Y[equation_times - 1L, , drop = FALSE]
  
  Ylag <- Y[equation_times - 1L, , drop = FALSE]
  
  if (p > 1L) {
    short_run_blocks <- lapply(seq_len(p - 1L), function(j) {
      DY[equation_times - 1L - j, , drop = FALSE]
    })
    
    W <- do.call(cbind, short_run_blocks)
  } else {
    W <- matrix(numeric(0), nrow = length(equation_times), ncol = 0)
  }
  
  # The equation at t = break_t is assigned to regime 2
  regime <- ifelse(equation_times < break_t, 1L, 2L)
  
  if (!all(c(1L, 2L) %in% regime))
    stop("Both regimes must contain usable observations.")
  
  # ------------------------------------------------------------
  # Identification of beta
  #
  # beta[norm_rows, ] = I_r
  # ------------------------------------------------------------
  
  other_rows <- setdiff(seq_len(K), norm_rows)
  number_beta_parameters <- (K - r) * r
  
  make_beta <- function(theta) {
    
    beta <- matrix(0, nrow = K, ncol = r)
    
    beta[norm_rows, ] <- diag(r)
    
    beta[other_rows, ] <- matrix(
      theta,
      nrow = K - r,
      ncol = r
    )
    
    rownames(beta) <- colnames(Y)
    colnames(beta) <- paste0("beta", seq_len(r))
    
    beta
  }
  
  # ------------------------------------------------------------
  # Concentrated likelihood conditional on beta
  # ------------------------------------------------------------
  
  fit_given_beta <- function(beta, return_details = FALSE) {
    
    error_correction <- Ylag %*% beta
    
    fits <- vector("list", 2L)
    
    for (s in 1:2) {
      
      index <- which(regime == s)
      
      X <- cbind(
        error_correction[index, , drop = FALSE],
        W[index, , drop = FALSE]
      )
      
      if (include_intercept)
        X <- cbind(X, intercept = 1)
      
      coefficients <- tryCatch(
        qr.solve(
          X,
          Ydep[index, , drop = FALSE],
          tol = 1e-10
        ),
        error = function(e) NULL
      )
      
      if (is.null(coefficients))
        return(list(logLik = -Inf))
      
      residuals <- Ydep[index, , drop = FALSE] -
        X %*% coefficients
      
      fits[[s]] <- list(
        index        = index,
        coefficients = coefficients,
        residuals    = residuals
      )
    }
    
    # ----------------------------------------------------------
    # Gaussian concentrated log likelihood
    # ----------------------------------------------------------
    
    if (covariance == "separate") {
      
      log_likelihood <- 0
      
      for (s in 1:2) {
        
        E  <- fits[[s]]$residuals
        ns <- nrow(E)
        
        Omega <- crossprod(E) / ns
        logdet <- determinant(Omega, logarithm = TRUE)
        
        if (logdet$sign <= 0 ||
            !is.finite(as.numeric(logdet$modulus))) {
          return(list(logLik = -Inf))
        }
        
        log_likelihood <- log_likelihood -
          0.5 * ns * (
            K * (1 + log(2 * pi)) +
              as.numeric(logdet$modulus)
          )
        
        fits[[s]]$Omega <- Omega
      }
      
    } else {
      
      E <- do.call(rbind, lapply(fits, `[[`, "residuals"))
      n <- nrow(E)
      
      Omega <- crossprod(E) / n
      logdet <- determinant(Omega, logarithm = TRUE)
      
      if (logdet$sign <= 0 ||
          !is.finite(as.numeric(logdet$modulus))) {
        return(list(logLik = -Inf))
      }
      
      log_likelihood <- -0.5 * n * (
        K * (1 + log(2 * pi)) +
          as.numeric(logdet$modulus)
      )
      
      fits[[1]]$Omega <- Omega
      fits[[2]]$Omega <- Omega
    }
    
    if (!return_details)
      return(list(logLik = log_likelihood))
    
    # Recover alpha, Gamma and intercepts
    number_short_run_columns <- ncol(W)
    
    for (s in 1:2) {
      
      C <- fits[[s]]$coefficients
      
      # Coefficients are transposed because each column of C
      # corresponds to one equation
      fits[[s]]$alpha <- t(C[seq_len(r), , drop = FALSE])
      
      fits[[s]]$Gamma <- vector("list", max(p - 1L, 0L))
      
      if (p > 1L) {
        
        gamma_rows <- r + seq_len(number_short_run_columns)
        gamma_coefficients <- C[gamma_rows, , drop = FALSE]
        
        for (j in seq_len(p - 1L)) {
          
          rows_j <- ((j - 1L) * K + 1L):(j * K)
          
          fits[[s]]$Gamma[[j]] <-
            t(gamma_coefficients[rows_j, , drop = FALSE])
        }
      }
      
      fits[[s]]$intercept <- if (include_intercept) {
        drop(C[nrow(C), ])
      } else {
        rep(0, K)
      }
    }
    
    list(
      logLik = log_likelihood,
      fits   = fits
    )
  }
  
  objective <- function(theta) {
    
    beta <- make_beta(theta)
    ll   <- fit_given_beta(beta)$logLik
    
    if (is.finite(ll)) -ll else 1e100
  }
  
  # ------------------------------------------------------------
  # Starting value for beta
  # ------------------------------------------------------------
  
  initial_theta <- rep(0, number_beta_parameters)
  
  if (!is.null(beta_start)) {
    
    beta_start <- as.matrix(beta_start)
    
    if (!all(dim(beta_start) == c(K, r)))
      stop("beta_start must be a K by rank matrix.")
    
    normalization_block <-
      beta_start[norm_rows, , drop = FALSE]
    
    if (abs(det(normalization_block)) < 1e-10) {
      stop("Selected norm_rows do not identify beta_start.")
    }
    
    normalized_beta <-
      beta_start %*% solve(normalization_block)
    
    initial_theta <-
      as.vector(normalized_beta[other_rows, , drop = FALSE])
  }
  
  # Several starting points reduce the risk of a local maximum
  set.seed(seed)
  
  starting_values <- vector("list", n_starts)
  starting_values[[1]] <- initial_theta
  
  if (n_starts > 1L) {
    for (i in 2:n_starts) {
      starting_values[[i]] <-
        initial_theta +
        rnorm(number_beta_parameters, mean = 0, sd = 0.35)
    }
  }
  
  optimization_results <- lapply(starting_values, function(start) {
    
    optim(
      par     = start,
      fn      = objective,
      method  = "BFGS",
      control = list(
        maxit  = maxit,
        reltol = reltol
      )
    )
  })
  
  objective_values <- vapply(
    optimization_results,
    function(x) x$value,
    numeric(1)
  )
  
  best_optimization <-
    optimization_results[[which.min(objective_values)]]
  
  beta_hat <- make_beta(best_optimization$par)
  
  final_fit <- fit_given_beta(
    beta_hat,
    return_details = TRUE
  )
  
  result <- list(
    beta        = beta_hat,
    alpha_1     = final_fit$fits[[1]]$alpha,
    alpha_2     = final_fit$fits[[2]]$alpha,
    Gamma_1     = final_fit$fits[[1]]$Gamma,
    Gamma_2     = final_fit$fits[[2]]$Gamma,
    intercept_1 = final_fit$fits[[1]]$intercept,
    intercept_2 = final_fit$fits[[2]]$intercept,
    Omega_1     = final_fit$fits[[1]]$Omega,
    Omega_2     = final_fit$fits[[2]]$Omega,
    logLik       = final_fit$logLik,
    convergence  = best_optimization$convergence,
    beta_par     = best_optimization$par,
    equation_times = equation_times,
    regime       = regime,
    break_t      = break_t,
    rank         = r,
    lag_level    = p,
    covariance   = covariance,
    norm_rows    = norm_rows
  )
  
  class(result) <- "common_beta_break_vecm"
  result
}

logLik.common_beta_break_vecm <- function(object, ...) {
  
  structure(
    object$logLik,
    class = "logLik",
    nobs  = length(object$equation_times)
  )
}




estimate_separate_vecms <- function(
    Y,
    break_t,
    rank,
    lag_level = 2,
    norm_rows_1 = seq_len(rank),
    norm_rows_2 = seq_len(rank),
    beta_start_1 = NULL,
    beta_start_2 = NULL,
    include_intercept = TRUE,
    n_starts = 10,
    seed = 123,
    maxit = 3000,
    reltol = 1e-10) {
  
  Y <- as.matrix(Y)
  storage.mode(Y) <- "double"
  
  TT <- nrow(Y)
  K  <- ncol(Y)
  r  <- rank
  p  <- lag_level
  
  if (r >= K)
    stop("rank must be smaller than the number of variables.")
  
  if (break_t <= p || break_t > TT)
    stop("Invalid break point.")
  
  # ------------------------------------------------------------
  # Construct the full VECM sample before dividing into regimes
  # ------------------------------------------------------------
  
  equation_times <- (p + 1L):TT
  DY <- diff(Y)
  
  Ydep <- Y[equation_times, , drop = FALSE] -
    Y[equation_times - 1L, , drop = FALSE]
  
  Ylag <- Y[equation_times - 1L, , drop = FALSE]
  
  if (p > 1L) {
    
    short_run_blocks <- lapply(seq_len(p - 1L), function(j) {
      DY[equation_times - 1L - j, , drop = FALSE]
    })
    
    W <- do.call(cbind, short_run_blocks)
    
  } else {
    
    W <- matrix(
      numeric(0),
      nrow = length(equation_times),
      ncol = 0
    )
  }
  
  # t = break_t is the first equation in regime 2
  regime <- ifelse(equation_times < break_t, 1L, 2L)
  
  if (!all(c(1L, 2L) %in% regime))
    stop("Both regimes must contain usable observations.")
  
  # ------------------------------------------------------------
  # Estimate one regime-specific VECM
  # ------------------------------------------------------------
  
  estimate_one_regime <- function(
    regime_number,
    norm_rows,
    beta_start,
    random_seed) {
    
    index <- which(regime == regime_number)
    
    Ydep_s <- Ydep[index, , drop = FALSE]
    Ylag_s <- Ylag[index, , drop = FALSE]
    W_s    <- W[index, , drop = FALSE]
    times_s <- equation_times[index]
    
    ns <- nrow(Ydep_s)
    
    if (length(norm_rows) != r ||
        length(unique(norm_rows)) != r ||
        any(!norm_rows %in% seq_len(K))) {
      stop("norm_rows must contain rank distinct row numbers.")
    }
    
    other_rows <- setdiff(seq_len(K), norm_rows)
    number_beta_parameters <- (K - r) * r
    
    # Identification: beta[norm_rows, ] = I_r
    make_beta <- function(theta) {
      
      beta <- matrix(0, nrow = K, ncol = r)
      
      beta[norm_rows, ] <- diag(r)
      
      beta[other_rows, ] <- matrix(
        theta,
        nrow = K - r,
        ncol = r
      )
      
      rownames(beta) <- colnames(Y)
      colnames(beta) <- paste0("beta", seq_len(r))
      
      beta
    }
    
    # ----------------------------------------------------------
    # Concentrated likelihood conditional on beta
    # ----------------------------------------------------------
    
    fit_given_beta <- function(beta, return_details = FALSE) {
      
      error_correction <- Ylag_s %*% beta
      
      X <- cbind(
        error_correction,
        W_s
      )
      
      if (include_intercept)
        X <- cbind(X, intercept = 1)
      
      coefficients <- tryCatch(
        qr.solve(
          X,
          Ydep_s,
          tol = 1e-10
        ),
        error = function(e) NULL
      )
      
      if (is.null(coefficients))
        return(list(logLik = -Inf))
      
      residuals <- Ydep_s - X %*% coefficients
      
      # ML covariance estimator uses division by ns, not ns - df
      Omega <- crossprod(residuals) / ns
      
      logdet <- determinant(
        Omega,
        logarithm = TRUE
      )
      
      if (logdet$sign <= 0 ||
          !is.finite(as.numeric(logdet$modulus))) {
        return(list(logLik = -Inf))
      }
      
      log_likelihood <- -0.5 * ns * (
        K * (1 + log(2 * pi)) +
          as.numeric(logdet$modulus)
      )
      
      if (!return_details)
        return(list(logLik = log_likelihood))
      
      # Recover alpha
      alpha <- t(
        coefficients[seq_len(r), , drop = FALSE]
      )
      
      # Recover the short-run coefficient matrices
      Gamma <- vector("list", max(p - 1L, 0L))
      
      if (p > 1L) {
        
        number_short_run_columns <- ncol(W_s)
        
        gamma_rows <- r + seq_len(number_short_run_columns)
        
        gamma_coefficients <-
          coefficients[gamma_rows, , drop = FALSE]
        
        for (j in seq_len(p - 1L)) {
          
          rows_j <- ((j - 1L) * K + 1L):(j * K)
          
          Gamma[[j]] <- t(
            gamma_coefficients[rows_j, , drop = FALSE]
          )
        }
      }
      
      intercept <- if (include_intercept) {
        drop(coefficients[nrow(coefficients), ])
      } else {
        rep(0, K)
      }
      
      list(
        logLik      = log_likelihood,
        beta        = beta,
        alpha       = alpha,
        Gamma       = Gamma,
        intercept   = intercept,
        Omega       = Omega,
        residuals   = residuals,
        coefficients = coefficients
      )
    }
    
    objective <- function(theta) {
      
      ll <- fit_given_beta(
        make_beta(theta)
      )$logLik
      
      if (is.finite(ll)) -ll else 1e100
    }
    
    # ----------------------------------------------------------
    # Starting value
    # ----------------------------------------------------------
    
    initial_theta <- rep(0, number_beta_parameters)
    
    if (!is.null(beta_start)) {
      
      beta_start <- as.matrix(beta_start)
      
      if (!all(dim(beta_start) == c(K, r)))
        stop("Each beta_start must be a K by rank matrix.")
      
      normalization_block <-
        beta_start[norm_rows, , drop = FALSE]
      
      if (abs(det(normalization_block)) < 1e-10) {
        stop(
          paste0(
            "norm_rows do not identify beta_start in regime ",
            regime_number,
            "."
          )
        )
      }
      
      normalized_beta <-
        beta_start %*% solve(normalization_block)
      
      initial_theta <- as.vector(
        normalized_beta[other_rows, , drop = FALSE]
      )
    }
    
    # Multiple starting points
    set.seed(random_seed)
    
    starting_values <- vector("list", n_starts)
    starting_values[[1]] <- initial_theta
    
    if (n_starts > 1L) {
      for (i in 2:n_starts) {
        starting_values[[i]] <-
          initial_theta +
          rnorm(
            number_beta_parameters,
            mean = 0,
            sd = 0.35
          )
      }
    }
    
    optimization_results <- lapply(
      starting_values,
      function(start) {
        optim(
          par = start,
          fn = objective,
          method = "BFGS",
          control = list(
            maxit = maxit,
            reltol = reltol
          )
        )
      }
    )
    
    objective_values <- vapply(
      optimization_results,
      function(x) x$value,
      numeric(1)
    )
    
    best_optimization <-
      optimization_results[[which.min(objective_values)]]
    
    beta_hat <- make_beta(best_optimization$par)
    
    final_fit <- fit_given_beta(
      beta_hat,
      return_details = TRUE
    )
    
    list(
      regime       = regime_number,
      equation_times = times_s,
      nobs         = ns,
      beta         = final_fit$beta,
      alpha        = final_fit$alpha,
      Gamma        = final_fit$Gamma,
      intercept    = final_fit$intercept,
      Omega        = final_fit$Omega,
      residuals    = final_fit$residuals,
      logLik       = final_fit$logLik,
      convergence  = best_optimization$convergence,
      norm_rows    = norm_rows
    )
  }
  
  fit_1 <- estimate_one_regime(
    regime_number = 1,
    norm_rows      = norm_rows_1,
    beta_start     = beta_start_1,
    random_seed    = seed
  )
  
  fit_2 <- estimate_one_regime(
    regime_number = 2,
    norm_rows      = norm_rows_2,
    beta_start     = beta_start_2,
    random_seed    = seed + 1L
  )
  
  result <- list(
    regime_1 = fit_1,
    regime_2 = fit_2,
    logLik_1 = fit_1$logLik,
    logLik_2 = fit_2$logLik,
    logLik_unrestricted = fit_1$logLik + fit_2$logLik,
    break_t = break_t,
    rank = r,
    lag_level = p
  )
  
  class(result) <- "separate_break_vecms"
  result
}





fit_separate <- estimate_separate_vecms(
  Y           = sim$Y,
  break_t     = 151,
  rank        = 2,
  lag_level   = 2,
  norm_rows_1 = c(1, 3),
  norm_rows_2 = c(1, 3),
  n_starts    = 20
)








































