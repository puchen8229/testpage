# Targeted, matched bootstrap experiment:
# block QLR-RRR versus Gaussian exact-ML LR computed by GRRR
#
# Designs:
#   (K,r) = (3,2), (5,2), (7,2), (7,6)
#
# For every outer Monte Carlo sample, the same fitted-null bootstrap paths are
# used for:
#   1. block QLR-RRR;
#   2. ML LR with an oracle GRRR start;
#   3. ML LR with conventional feasible GRRR starts.
#
# Oracle convention:
#   * observed outer sample: start GRRR at population beta_1;
#   * fitted-null bootstrap sample: start GRRR at beta_hat_R, the conditional
#     generating space for that bootstrap.
#
# The oracle protocol is an infeasible computational diagnostic. Only the
# conventional protocol is operational. ML bootstrap p-values based on
# convergence-certified draws are primary; raw finite-draw p-values are also
# retained for audit.
#
# Required files in program_dir:
#   R_functions_for_Chatgpt.R
#   Hansen_GRRR_common_beta_v1.R
#   bootstrap_exact_ML_LR_vs_QLR_RRR.R
#
# The program is Windows-safe, checkpointed, restartable, and parallelizes the
# outer Monte Carlo loop with a PSOCK cluster.

options(stringsAsFactors = FALSE)

matched_required_functions <- c(
  "estimate_break_vecm_rrr",
  "estimate_separate_vecms_rrr",
  "estimate_common_beta_hansen_grrr",
  "bootstrap_exact_ml_lr_vs_qlr"
)

matched_load_methods <- function(program_dir = getwd()) {
  files <- file.path(
    program_dir,
    c(
      "R_functions_for_Chatgpt.R",
      "Hansen_GRRR_common_beta_v1.R",
      "bootstrap_exact_ML_LR_vs_QLR_RRR.R"
    )
  )
  missing <- files[!file.exists(files)]
  if (length(missing)) {
    stop("Missing required source file(s): ", paste(missing, collapse = ", "))
  }

  # Some historical bundles contain an unguarded example at the end of the
  # main methods file. Import definitions only.
  method_lines <- readLines(files[1L], warn = FALSE)
  cut <- grep(
    "^[[:space:]]*fit_separate[[:space:]]*<-[[:space:]]*estimate_separate_vecms\\(",
    method_lines
  )
  if (length(cut)) method_lines <- method_lines[seq_len(cut[1L] - 1L)]
  eval(parse(text = method_lines, keep.source = FALSE), envir = .GlobalEnv)

  # Some distributed versions call this helper but omit its definition.
  if (!exists("estimate_one_vecm_rrr", mode = "function", inherits = TRUE)) {
    estimate_one_vecm_rrr <- function(
        X0, X1, Z, equation_times, rank, lag_level = 2,
        norm_rows = seq_len(rank), include_intercept = TRUE,
        tolerance = 1e-10) {
      X0 <- as.matrix(X0)
      X1 <- as.matrix(X1)
      Z <- as.matrix(Z)
      K <- ncol(X0)
      r <- as.integer(rank)
      p <- as.integer(lag_level)
      R0 <- residualise(X0, Z, tolerance)
      R1 <- residualise(X1, Z, tolerance)
      rrr <- rrr_beta(R0, R1, r, norm_rows, tolerance)
      beta <- rrr$beta
      design <- cbind(X1 %*% beta, Z)
      coefficients <- qr.solve(design, X0, tol = tolerance)
      residuals <- X0 - design %*% coefficients
      likelihood <- gaussian_loglik(residuals)
      alpha <- t(coefficients[seq_len(r), , drop = FALSE])
      Gamma <- vector("list", max(p - 1L, 0L))
      if (p > 1L) {
        for (j in seq_len(p - 1L)) {
          rows_j <- r + ((j - 1L) * K + 1L):(j * K)
          Gamma[[j]] <- t(coefficients[rows_j, , drop = FALSE])
        }
      }
      intercept <- if (include_intercept) {
        drop(coefficients[nrow(coefficients), ])
      } else {
        rep(0, K)
      }
      list(
        equation_times = equation_times,
        nobs = nrow(X0),
        beta = beta,
        alpha = alpha,
        Gamma = Gamma,
        intercept = intercept,
        Omega = likelihood$Omega,
        residuals = residuals,
        logLik = likelihood$logLik,
        rrr = rrr
      )
    }
    assign(
      "estimate_one_vecm_rrr",
      estimate_one_vecm_rrr,
      envir = .GlobalEnv
    )
  }

  source(files[2L], local = .GlobalEnv)
  source(files[3L], local = .GlobalEnv)

  # The paired-bootstrap engine uses this fitted-null recursive simulator.
  if (!exists("simulate_null_path", mode = "function", inherits = TRUE)) {
    simulate_null_path <- function(fit, Y_initial, seed = NULL) {
      if (!is.null(seed)) set.seed(seed)
      Y_initial <- as.matrix(Y_initial)
      TT <- nrow(Y_initial)
      K <- ncol(Y_initial)
      p <- fit$lag_level
      break_t <- fit$break_t
      Ystar <- matrix(NA_real_, TT, K, dimnames = dimnames(Y_initial))
      Ystar[seq_len(p), ] <- Y_initial[seq_len(p), ]
      for (tt in (p + 1L):TT) {
        second <- tt >= break_t
        alpha <- if (second) fit$alpha_2 else fit$alpha_1
        Gamma <- if (second) fit$Gamma_2 else fit$Gamma_1
        intercept <- if (second) fit$intercept_2 else fit$intercept_1
        Omega <- if (second) fit$Omega_2 else fit$Omega_1
        dy <- drop(
          intercept + alpha %*% crossprod(fit$beta, Ystar[tt - 1L, ])
        )
        if (p > 1L) {
          for (j in seq_len(p - 1L)) {
            previous_dy <- Ystar[tt - j, ] - Ystar[tt - j - 1L, ]
            dy <- dy + drop(Gamma[[j]] %*% previous_dy)
          }
        }
        innovation <- drop(t(chol(Omega)) %*% rnorm(K))
        Ystar[tt, ] <- Ystar[tt - 1L, ] + dy + innovation
      }
      Ystar
    }
    assign("simulate_null_path", simulate_null_path, envir = .GlobalEnv)
  }

  matched_required_functions <- c(
    matched_required_functions,
    "simulate_null_path",
    "estimate_one_vecm_rrr"
  )
  absent <- matched_required_functions[
    !vapply(
      matched_required_functions,
      exists,
      logical(1),
      mode = "function",
      inherits = TRUE
    )
  ]
  if (length(absent)) {
    stop("Required functions were not loaded: ", paste(absent, collapse = ", "))
  }
  invisible(TRUE)
}

matched_orth <- function(A, tol = 1e-10) {
  A <- as.matrix(A)
  ee <- eigen(crossprod(A), symmetric = TRUE)
  keep <- ee$values > tol * max(1, ee$values[1L])
  if (!any(keep)) stop("Matrix has no numerically nonzero columns.")
  A %*% ee$vectors[, keep, drop = FALSE] %*%
    diag(1 / sqrt(ee$values[keep]), sum(keep))
}

matched_beta <- function(K, r) {
  stopifnot(K >= 2L, r >= 1L, r < K)
  beta <- matrix(0, K, r)
  beta[seq_len(r), ] <- diag(r)
  m <- K - r
  ii <- matrix(seq_len(m), m, r)
  jj <- matrix(rep(seq_len(r), each = m), m, r)
  loadings <- 0.35 * sin(0.73 * ii * jj) +
    0.20 * cos(1.17 * ii + 0.41 * jj)
  beta[(r + 1L):K, ] <- loadings / max(1, sqrt(r / 2))
  beta
}

matched_rotate_space <- function(beta_1, angle) {
  # Rotates d=min(r,K-r) orthogonal directions by a common principal angle.
  # Remaining r-d directions are shared. At angle=0 the null holds exactly.
  beta_1 <- as.matrix(beta_1)
  K <- nrow(beta_1)
  r <- ncol(beta_1)
  if (angle < 0 || angle >= pi / 2) {
    stop("angle must lie in [0, pi/2).")
  }
  Q1 <- qr.Q(qr(beta_1), complete = TRUE)[, seq_len(r), drop = FALSE]
  Qperp <- qr.Q(qr(beta_1), complete = TRUE)[
    , (r + 1L):K, drop = FALSE
  ]
  d <- min(r, K - r)
  Q2 <- Q1
  if (d > 0L && angle > 0) {
    rotate_cols <- (r - d + 1L):r
    Q2[, rotate_cols] <-
      cos(angle) * Q1[, rotate_cols, drop = FALSE] +
      sin(angle) * Qperp[, seq_len(d), drop = FALSE]
  }
  Q2
}

matched_subspace_distance <- function(beta_1, beta_2) {
  Q1 <- matched_orth(beta_1)
  Q2 <- matched_orth(beta_2)
  cc <- svd(crossprod(Q1, Q2), nu = 0, nv = 0)$d
  angles <- acos(pmin(1, pmax(0, cc)))
  c(
    max_principal_angle = max(angles),
    chordal_distance = sqrt(sum(sin(angles)^2)),
    projector_distance = max(sin(angles))
  )
}

matched_dgp_parameters <- function(K, r, angle = 0) {
  beta_1 <- matched_beta(K, r)
  beta_2 <- matched_rotate_space(beta_1, angle)

  # alpha_s beta_s' has eigenvalues -a_s in the cointegrating directions.
  alpha_for <- function(beta, speed) {
    -speed * beta %*% solve(crossprod(beta))
  }
  alpha_1 <- alpha_for(beta_1, 0.22)
  alpha_2 <- alpha_for(beta_2, 0.36)

  Gamma_1 <- 0.12 * diag(K)
  Gamma_2 <- 0.05 * diag(K)
  if (K > 1L) {
    for (i in seq_len(K - 1L)) {
      Gamma_1[i, i + 1L] <- 0.018 * (-1)^i
      Gamma_2[i + 1L, i] <- 0.025 * (-1)^i
    }
  }

  idx <- seq_len(K)
  Omega_1 <- 0.25^abs(outer(idx, idx, "-"))
  scales <- seq(0.85, 1.25, length.out = K)
  Omega_2 <- 1.20 * (scales %o% scales) * Omega_1

  list(
    beta_1 = beta_1,
    beta_2 = beta_2,
    alpha_1 = alpha_1,
    alpha_2 = alpha_2,
    Gamma_1 = Gamma_1,
    Gamma_2 = Gamma_2,
    Omega_1 = Omega_1,
    Omega_2 = Omega_2,
    distance = matched_subspace_distance(beta_1, beta_2)
  )
}

matched_simulate_vecm <- function(
    K, r, T = 300L, break_t = floor(T / 2) + 1L,
    angle = 0, burn_in = 200L, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  pars <- matched_dgp_parameters(K, r, angle)
  total <- as.integer(T + burn_in)
  break_full <- as.integer(burn_in + break_t)
  Y <- matrix(0, total, K)
  DY <- matrix(0, total, K)
  C1 <- chol(pars$Omega_1)
  C2 <- chol(pars$Omega_2)

  for (tt in 2:total) {
    regime_2 <- tt >= break_full
    beta <- if (regime_2) pars$beta_2 else pars$beta_1
    alpha <- if (regime_2) pars$alpha_2 else pars$alpha_1
    Gamma <- if (regime_2) pars$Gamma_2 else pars$Gamma_1
    C <- if (regime_2) C2 else C1
    eps <- drop(rnorm(K) %*% C)
    ec <- drop(alpha %*% crossprod(beta, Y[tt - 1L, ]))
    DY[tt, ] <- ec + drop(Gamma %*% DY[tt - 1L, ]) + eps
    Y[tt, ] <- Y[tt - 1L, ] + DY[tt, ]
  }

  list(
    Y = Y[(burn_in + 1L):(burn_in + T), , drop = FALSE],
    beta_1 = pars$beta_1,
    beta_2 = pars$beta_2,
    distance = pars$distance,
    parameters = pars
  )
}

matched_boot_p <- function(values, observed, valid = rep(TRUE, length(values))) {
  valid <- valid & is.finite(values)
  n <- sum(valid)
  if (!n) {
    return(c(p = NA_real_, MCSE = NA_real_, valid = 0, valid_fraction = 0))
  }
  p <- (1 + sum(values[valid] >= observed)) / (n + 1)
  c(
    p = p,
    MCSE = sqrt(p * (1 - p) / n),
    valid = n,
    valid_fraction = n / length(values)
  )
}

matched_extract_results <- function(
    ans, alpha = 0.05, minimum_certified_fraction = 0.90,
    minimum_agreeing_starts = 2L, tolerance = 1e-10) {
  z <- ans$bootstrap_draws
  ell_U_obs <- ans$observed_fits$unrestricted$logLik
  oracle_obs <- ans$observed_fits$oracle
  conventional_obs <- ans$observed_fits$conventional
  oracle_observed_certified <-
    isTRUE(oracle_obs$converged) &&
    ell_U_obs + tolerance >= oracle_obs$logLik
  conventional_observed_certified <-
    isTRUE(conventional_obs$converged) &&
    conventional_obs$starts_agreeing >= minimum_agreeing_starts &&
    ell_U_obs + tolerance >= conventional_obs$logLik

  qlr_valid <- z$successful & is.finite(z$QLR_RRR)
  oracle_certified <- qlr_valid &
    z$oracle_converged &
    z$ordering_oracle_ok &
    is.finite(z$LR_ML_oracle)
  conventional_certified <- qlr_valid &
    z$conventional_converged &
    z$conventional_starts_agreeing >= minimum_agreeing_starts &
    z$ordering_conventional_ok &
    is.finite(z$LR_ML_conventional)

  qlr <- matched_boot_p(
    z$QLR_RRR, ans$observed["QLR_RRR"], qlr_valid
  )
  oracle_cert <- matched_boot_p(
    z$LR_ML_oracle,
    ans$observed["LR_ML_oracle"],
    oracle_certified
  )
  conventional_cert <- matched_boot_p(
    z$LR_ML_conventional,
    ans$observed["LR_ML_conventional"],
    conventional_certified
  )
  oracle_raw <- matched_boot_p(
    z$LR_ML_oracle, ans$observed["LR_ML_oracle"], qlr_valid
  )
  conventional_raw <- matched_boot_p(
    z$LR_ML_conventional,
    ans$observed["LR_ML_conventional"],
    qlr_valid
  )

  oracle_usable <-
    oracle_observed_certified &&
    oracle_cert["valid_fraction"] >= minimum_certified_fraction
  conventional_usable <-
    conventional_observed_certified &&
    conventional_cert["valid_fraction"] >= minimum_certified_fraction

  data.frame(
    QLR_RRR = unname(ans$observed["QLR_RRR"]),
    LR_ML_oracle = unname(ans$observed["LR_ML_oracle"]),
    LR_ML_conventional = unname(ans$observed["LR_ML_conventional"]),
    p_QLR_boot = qlr["p"],
    p_ML_oracle_certified = if (oracle_usable) oracle_cert["p"] else NA_real_,
    p_ML_conventional_certified =
      if (conventional_usable) conventional_cert["p"] else NA_real_,
    p_ML_oracle_raw = oracle_raw["p"],
    p_ML_conventional_raw = conventional_raw["p"],
    MCSE_QLR = qlr["MCSE"],
    MCSE_ML_oracle_certified = oracle_cert["MCSE"],
    MCSE_ML_conventional_certified = conventional_cert["MCSE"],
    QLR_valid_fraction = qlr["valid_fraction"],
    ML_oracle_certified_fraction = oracle_cert["valid_fraction"],
    ML_conventional_certified_fraction =
      conventional_cert["valid_fraction"],
    ML_oracle_observed_certified = oracle_observed_certified,
    ML_conventional_observed_certified =
      conventional_observed_certified,
    ML_oracle_bootstrap_usable = oracle_usable,
    ML_conventional_bootstrap_usable = conventional_usable,
    reject_QLR = qlr["p"] <= alpha,
    reject_ML_oracle = if (oracle_usable) oracle_cert["p"] <= alpha else NA,
    reject_ML_conventional =
      if (conventional_usable) conventional_cert["p"] <= alpha else NA,
    oracle_conventional_decision_disagree =
      if (oracle_usable && conventional_usable) {
        (oracle_cert["p"] <= alpha) !=
          (conventional_cert["p"] <= alpha)
      } else {
        NA
      },
    QLR_oracle_decision_disagree =
      if (oracle_usable) {
        (qlr["p"] <= alpha) != (oracle_cert["p"] <= alpha)
      } else {
        NA
      },
    QLR_conventional_decision_disagree =
      if (conventional_usable) {
        (qlr["p"] <= alpha) != (conventional_cert["p"] <= alpha)
      } else {
        NA
      },
    oracle_improves_conventional_rate = mean(
      z$oracle_improves_conventional[qlr_valid], na.rm = TRUE
    ),
    conventional_all_starts_agree_rate = mean(
      z$conventional_starts_agreeing[qlr_valid] ==
        z$conventional_starts_total[qlr_valid],
      na.rm = TRUE
    ),
    conventional_mean_start_agreement = mean(
      z$conventional_agreement_fraction[qlr_valid], na.rm = TRUE
    ),
    stringsAsFactors = FALSE
  )
}

matched_one_replication <- function(
    replication, seed, K, r, T, break_t, angle, B,
    number_random_starts, maximum_iterations,
    minimum_certified_fraction, minimum_agreeing_starts,
    alpha, tolerance) {
  started <- proc.time()[["elapsed"]]
  out <- tryCatch({
    sim <- matched_simulate_vecm(
      K = K, r = r, T = T, break_t = break_t,
      angle = angle, seed = seed
    )

    paired <- bootstrap_exact_ml_lr_vs_qlr(
      Y = sim$Y,
      break_t = break_t,
      rank = r,
      lag_level = 2L,
      norm_rows = seq_len(r),
      B = B,
      seed = seed + 100003L,
      include_intercept = TRUE,
      number_random_starts = number_random_starts,
      observed_oracle_beta = sim$beta_1,
      maximum_iterations = maximum_iterations,
      likelihood_tolerance = 1e-10,
      beta_tolerance = 1e-8,
      agreement_tolerance = 1e-6,
      tolerance = tolerance,
      workers = 1L,
      progress_every = 0L
    )

    row <- matched_extract_results(
      paired,
      alpha = alpha,
      minimum_certified_fraction = minimum_certified_fraction,
      minimum_agreeing_starts = minimum_agreeing_starts,
      tolerance = tolerance
    )
    row$replication <- replication
    row$seed <- seed
    row$K <- K
    row$rank <- r
    row$q <- r * (K - r)
    row$T <- T
    row$break_t <- break_t
    row$angle <- angle
    row$max_principal_angle <- sim$distance["max_principal_angle"]
    row$chordal_distance <- sim$distance["chordal_distance"]
    row$successful <- TRUE
    row$error <- NA_character_
    row$elapsed_seconds <- proc.time()[["elapsed"]] - started
    row
  }, error = function(e) {
    data.frame(
      replication = replication,
      seed = seed,
      K = K,
      rank = r,
      q = r * (K - r),
      T = T,
      break_t = break_t,
      angle = angle,
      successful = FALSE,
      error = conditionMessage(e),
      elapsed_seconds = proc.time()[["elapsed"]] - started,
      stringsAsFactors = FALSE
    )
  })
  out
}

matched_rbind_fill <- function(items) {
  items <- Filter(function(x) !is.null(x) && nrow(x), items)
  if (!length(items)) return(data.frame())
  all_names <- unique(unlist(lapply(items, names), use.names = FALSE))
  items <- lapply(items, function(x) {
    absent <- setdiff(all_names, names(x))
    for (nm in absent) x[[nm]] <- NA
    x[all_names]
  })
  do.call(rbind, items)
}

matched_rate <- function(x) {
  if (!length(x) || all(is.na(x))) return(NA_real_)
  mean(x, na.rm = TRUE)
}

matched_mcse <- function(p, n) {
  if (!is.finite(p) || n <= 0L) return(NA_real_)
  sqrt(p * (1 - p) / n)
}

matched_summarise_cell <- function(x, R_requested, alpha = 0.05) {
  good <- x[x$successful %in% TRUE, , drop = FALSE]
  if (!nrow(good)) stop("No successful replications to summarize.")

  qlr_n <- sum(!is.na(good$reject_QLR))
  oracle_n <- sum(!is.na(good$reject_ML_oracle))
  conventional_n <- sum(!is.na(good$reject_ML_conventional))
  qlr_rate <- matched_rate(good$reject_QLR)
  oracle_rate <- matched_rate(good$reject_ML_oracle)
  conventional_rate <- matched_rate(good$reject_ML_conventional)

  data.frame(
    K = good$K[1L],
    rank = good$rank[1L],
    q = good$q[1L],
    T = good$T[1L],
    angle = good$angle[1L],
    chordal_distance = good$chordal_distance[1L],
    alpha = alpha,
    replications_requested = R_requested,
    replications_successful = nrow(good),
    outer_failure_rate = 1 - nrow(good) / R_requested,
    rejection_QLR = qlr_rate,
    MCSE_rejection_QLR = matched_mcse(qlr_rate, qlr_n),
    rejection_ML_oracle = oracle_rate,
    MCSE_rejection_ML_oracle =
      matched_mcse(oracle_rate, oracle_n),
    rejection_ML_conventional = conventional_rate,
    MCSE_rejection_ML_conventional =
      matched_mcse(conventional_rate, conventional_n),
    usable_ML_oracle_outer_fraction =
      matched_rate(good$ML_oracle_bootstrap_usable),
    usable_ML_conventional_outer_fraction =
      matched_rate(good$ML_conventional_bootstrap_usable),
    mean_ML_oracle_certified_fraction =
      mean(good$ML_oracle_certified_fraction, na.rm = TRUE),
    mean_ML_conventional_certified_fraction =
      mean(good$ML_conventional_certified_fraction, na.rm = TRUE),
    QLR_oracle_decision_disagreement =
      matched_rate(good$QLR_oracle_decision_disagree),
    QLR_conventional_decision_disagreement =
      matched_rate(good$QLR_conventional_decision_disagree),
    oracle_conventional_decision_disagreement =
      matched_rate(good$oracle_conventional_decision_disagree),
    mean_oracle_improves_conventional_rate =
      mean(good$oracle_improves_conventional_rate, na.rm = TRUE),
    mean_conventional_all_starts_agree_rate =
      mean(good$conventional_all_starts_agree_rate, na.rm = TRUE),
    median_elapsed_minutes =
      median(good$elapsed_seconds, na.rm = TRUE) / 60,
    q90_elapsed_minutes =
      unname(quantile(good$elapsed_seconds, 0.90, na.rm = TRUE)) / 60,
    stringsAsFactors = FALSE
  )
}

run_targeted_matched_cell <- function(
    K, r, angle,
    program_dir = getwd(),
    output_dir = file.path(program_dir, "targeted_matched_ML_QLR"),
    R = 100L,
    B = 199L,
    T = 300L,
    number_random_starts = 3L,
    maximum_iterations = 1500L,
    minimum_certified_fraction = 0.90,
    minimum_agreeing_starts = 2L,
    alpha = 0.05,
    workers = max(1L, parallel::detectCores(logical = FALSE) - 1L),
    seed = 20260724L,
    checkpoint_every = 5L,
    tolerance = 1e-10) {
  stopifnot(K >= 2L, r >= 1L, r < K, R >= 1L, B >= 9L)
  matched_load_methods(program_dir)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

  angle_tag <- gsub("\\.", "p", format(angle, trim = TRUE))
  tag <- sprintf(
    "K%d_r%d_T%d_angle%s_R%d_B%d",
    K, r, T, angle_tag, R, B
  )
  results_file <- file.path(output_dir, paste0(tag, "_replications.csv"))
  summary_file <- file.path(output_dir, paste0(tag, "_summary.csv"))

  old <- if (file.exists(results_file)) read.csv(results_file) else data.frame()
  completed <- if (nrow(old)) old$replication else integer(0)
  set.seed(seed + 1009L * K + 9176L * r + round(1e5 * angle))
  seeds <- sample.int(.Machine$integer.max - 200000L, R, replace = FALSE)
  pending <- setdiff(seq_len(R), completed)
  break_t <- floor(T / 2) + 1L

  if (length(pending)) {
    workers <- min(as.integer(workers), length(pending))
    cl <- parallel::makeCluster(max(1L, workers))
    on.exit(parallel::stopCluster(cl), add = TRUE)
    export_names <- ls(envir = .GlobalEnv)
    parallel::clusterExport(cl, export_names, envir = .GlobalEnv)

    chunks <- split(
      pending,
      ceiling(seq_along(pending) / as.integer(checkpoint_every))
    )
    for (cc in seq_along(chunks)) {
      ids <- chunks[[cc]]
      fresh <- parallel::parLapplyLB(cl, ids, function(i) {
        matched_one_replication(
          replication = i,
          seed = seeds[i],
          K = K,
          r = r,
          T = T,
          break_t = break_t,
          angle = angle,
          B = B,
          number_random_starts = number_random_starts,
          maximum_iterations = maximum_iterations,
          minimum_certified_fraction = minimum_certified_fraction,
          minimum_agreeing_starts = minimum_agreeing_starts,
          alpha = alpha,
          tolerance = tolerance
        )
      })
      old <- matched_rbind_fill(list(old, matched_rbind_fill(fresh)))
      old <- old[order(old$replication), , drop = FALSE]
      write.csv(old, results_file, row.names = FALSE)
      message(tag, ": completed ", nrow(old), "/", R)
    }
  }

  summary <- matched_summarise_cell(old, R_requested = R, alpha = alpha)
  write.csv(summary, summary_file, row.names = FALSE)
  summary
}

matched_default_grid <- function(
    null_angle = 0,
    power_angles = c(0.10, 0.20, 0.35)) {
  designs <- data.frame(
    K = c(3L, 5L, 7L, 7L),
    rank = c(2L, 2L, 2L, 6L)
  )
  grid <- merge(
    designs,
    data.frame(angle = c(null_angle, power_angles)),
    all = TRUE
  )
  grid[order(grid$K, grid$rank, grid$angle), , drop = FALSE]
}

run_targeted_matched_experiment <- function(
    program_dir = getwd(),
    output_dir = file.path(program_dir, "targeted_matched_ML_QLR"),
    grid = matched_default_grid(),
    R = 100L,
    B = 199L,
    T = 300L,
    number_random_starts = 3L,
    maximum_iterations = 1500L,
    minimum_certified_fraction = 0.90,
    minimum_agreeing_starts = 2L,
    alpha = 0.05,
    workers = max(1L, parallel::detectCores(logical = FALSE) - 1L),
    seed = 20260724L,
    checkpoint_every = 5L,
    tolerance = 1e-10) {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  write.csv(
    grid,
    file.path(output_dir, "targeted_matched_design_grid.csv"),
    row.names = FALSE
  )

  summaries <- vector("list", nrow(grid))
  for (g in seq_len(nrow(grid))) {
    message(
      "Starting cell ", g, "/", nrow(grid),
      ": K=", grid$K[g],
      ", r=", grid$rank[g],
      ", angle=", grid$angle[g]
    )
    summaries[[g]] <- run_targeted_matched_cell(
      K = grid$K[g],
      r = grid$rank[g],
      angle = grid$angle[g],
      program_dir = program_dir,
      output_dir = output_dir,
      R = R,
      B = B,
      T = T,
      number_random_starts = number_random_starts,
      maximum_iterations = maximum_iterations,
      minimum_certified_fraction = minimum_certified_fraction,
      minimum_agreeing_starts = minimum_agreeing_starts,
      alpha = alpha,
      workers = workers,
      seed = seed,
      checkpoint_every = checkpoint_every,
      tolerance = tolerance
    )
  }
  ans <- do.call(rbind, summaries)
  write.csv(
    ans,
    file.path(output_dir, "targeted_matched_all_cells_summary.csv"),
    row.names = FALSE
  )
  ans
}

# -------------------------------------------------------------------------
# Recommended workflow on Windows
# -------------------------------------------------------------------------
#
# setwd("C:/Users/Pu Chen/OneDrive - Curtin/Research/Economics/paper2plublish/QLR_RRR/program")
# source("run_targeted_matched_ML_QLR_bootstrap_experiment.R")
#
# 1. Smoke test: null only, two outer replications, nine bootstrap draws.
# smoke_grid <- matched_default_grid(power_angles = numeric(0))
# smoke <- run_targeted_matched_experiment(
#   program_dir = getwd(),
#   output_dir = file.path(getwd(), "targeted_matched_smoke"),
#   grid = smoke_grid,
#   R = 2, B = 9, number_random_starts = 1,
#   maximum_iterations = 300, workers = 2
# )
#
# 2. Development run.
# development <- run_targeted_matched_experiment(
#   program_dir = getwd(),
#   output_dir = file.path(getwd(), "targeted_matched_development"),
#   R = 100, B = 199, number_random_starts = 3, workers = 4
# )
#
# 3. Final selected-cell run.
# final <- run_targeted_matched_experiment(
#   program_dir = getwd(),
#   output_dir = file.path(getwd(), "targeted_matched_final"),
#   R = 500, B = 399, number_random_starts = 10,
#   maximum_iterations = 2000, workers = 6
# )
#
# If full power analysis is too costly, run the four null cells first:
# null_only <- matched_default_grid(power_angles = numeric(0))
# final_null <- run_targeted_matched_experiment(
#   grid = null_only, R = 500, B = 399, number_random_starts = 10
# )
