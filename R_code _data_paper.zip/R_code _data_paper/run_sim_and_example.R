source("US_Treasury_common_space_application_v1.R")
source("Hansen_GRRR_common_beta_v1.R")

result <- run_term_structure_example(
  method_file = "R_functions_for_Chatgpt.R",
  hansen_file = "Hansen_GRRR_common_beta_v1.R",
  B = 199,
  run_hansen = TRUE,
  hansen_starts = 10
)


rm(list = ls())

source("US_Treasury_common_space_application_v1.R")
source("Hansen_GRRR_common_beta_v1.R")

result_K7 <- run_seven_yield_example(
  method_file = "R_functions_for_Chatgpt.R",
  hansen_file = "Hansen_GRRR_common_beta_v1.R",
  B = 199,
  hansen_starts = 10,
  rank = 6
)


result_K7_B4999 <- run_seven_yield_example(
  method_file = "R_functions_for_Chatgpt.R",
  hansen_file = "Hansen_GRRR_common_beta_v1.R",
  B = 4999,
  hansen_starts = 30,
  rank = 6,
  output_directory = "US_Treasury_K7_r6_B4999"
)