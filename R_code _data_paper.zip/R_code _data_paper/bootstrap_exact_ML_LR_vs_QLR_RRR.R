# Paired recursive bootstrap for block QLR_RRR and the implemented exact-ML LR
#
# Required source files:
#   QLR_RRR_methods_v0_2.R
#   Hansen_GRRR_common_beta_v1.R
#
# The unrestricted likelihood is always computed by two separate Johansen
# reduced-rank regressions.  Only the restricted common-beta likelihood uses
# Hansen's iterative GRRR procedure.
#
# Two restricted-ML initialization protocols are compared:
#   oracle       one GRRR run initialized at beta_oracle;
#   conventional block-RRR, zero-chart and random starts.
#
# In a Monte Carlo experiment beta_oracle may be the population beta0.  This is
# an infeasible diagnostic, not a usable test.  In an empirical fitted-null
# bootstrap the conditional analogue is the null-generating beta_hat_R.

normalise_boot_beta <- function(beta, norm_rows) {
  beta <- as.matrix(beta)
  beta %*% solve(beta[norm_rows, , drop = FALSE])
}

finite_range <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) < 2L) return(if (length(x)) 0 else NA_real_)
  diff(range(x))
}

fit_restricted_ml_protocol <- function(
    Y, break_t, rank, lag_level, norm_rows, include_intercept,
    protocol = c("conventional", "oracle"),
    beta_oracle = NULL,
    number_random_starts = 10L,
    seed = 20260724L,
    maximum_iterations = 2000L,
    likelihood_tolerance = 1e-10,
    beta_tolerance = 1e-8,
    agreement_tolerance = 1e-6,
    tolerance = 1e-10) {
  protocol <- match.arg(protocol)

  if (protocol == "oracle") {
    if (is.null(beta_oracle)) {
      stop("The oracle protocol requires beta_oracle.")
    }
    fit <- estimate_common_beta_hansen_grrr(
      Y = Y, break_t = break_t, rank = rank, lag_level = lag_level,
      norm_rows = norm_rows, include_intercept = include_intercept,
      covariance = "separate",
      beta_starts = list(normalise_boot_beta(beta_oracle, norm_rows)),
      include_block_rrr_start = FALSE,
      include_zero_chart_start = FALSE,
      number_random_starts = 0L,
      seed = seed,
      maximum_iterations = maximum_iterations,
      likelihood_tolerance = likelihood_tolerance,
      beta_tolerance = beta_tolerance,
      agreement_tolerance = agreement_tolerance,
      tolerance = tolerance)
  } else {
    fit <- estimate_common_beta_hansen_grrr(
      Y = Y, break_t = break_t, rank = rank, lag_level = lag_level,
      norm_rows = norm_rows, include_intercept = include_intercept,
      covariance = "separate",
      beta_starts = NULL,
      include_block_rrr_start = TRUE,
      include_zero_chart_start = TRUE,
      number_random_starts = number_random_starts,
      seed = seed,
      maximum_iterations = maximum_iterations,
      likelihood_tolerance = likelihood_tolerance,
      beta_tolerance = beta_tolerance,
      agreement_tolerance = agreement_tolerance,
      tolerance = tolerance)
  }

  ll <- fit$start_summary$logLik
  list(
    fit = fit,
    logLik = fit$logLik,
    converged = isTRUE(fit$converged),
    starts_agreeing = fit$number_agreeing,
    starts_total = fit$number_starts,
    agreement_fraction = fit$number_agreeing / fit$number_starts,
    start_logLik_range = finite_range(ll),
    best_start = fit$best_start_label
  )
}

bootstrap_pvalue <- function(star, observed) {
  good <- is.finite(star)
  n <- sum(good)
  if (!n) return(list(p_value = NA_real_, MCSE = NA_real_, valid = 0L))
  p <- (1 + sum(star[good] >= observed)) / (n + 1)
  list(
    p_value = p,
    MCSE = sqrt(p * (1 - p) / n),
    valid = n,
    critical_values = unname(quantile(star[good], c(.90, .95, .99)))
  )
}

one_paired_bootstrap_draw <- function(
    b, draw_seed, Y, null_fit, break_t, rank, lag_level, norm_rows,
    include_intercept, number_random_starts, maximum_iterations,
    likelihood_tolerance, beta_tolerance, agreement_tolerance, tolerance) {
  ans <- tryCatch({
    Ys <- simulate_null_path(null_fit, Y, seed = draw_seed)

    block <- estimate_break_vecm_rrr(
      Ys, break_t, rank, lag_level, norm_rows,
      include_intercept, tolerance)
    unrestricted <- estimate_separate_vecms_rrr(
      Ys, break_t, rank, lag_level, norm_rows, norm_rows,
      include_intercept, tolerance)

    # Conditional on the fitted null, null_fit$beta is the generating
    # cointegration space for every bootstrap path.
    oracle <- fit_restricted_ml_protocol(
      Ys, break_t, rank, lag_level, norm_rows, include_intercept,
      protocol = "oracle", beta_oracle = null_fit$beta,
      seed = draw_seed + 101L,
      maximum_iterations = maximum_iterations,
      likelihood_tolerance = likelihood_tolerance,
      beta_tolerance = beta_tolerance,
      agreement_tolerance = agreement_tolerance,
      tolerance = tolerance)

    conventional <- fit_restricted_ml_protocol(
      Ys, break_t, rank, lag_level, norm_rows, include_intercept,
      protocol = "conventional",
      number_random_starts = number_random_starts,
      seed = draw_seed + 211L,
      maximum_iterations = maximum_iterations,
      likelihood_tolerance = likelihood_tolerance,
      beta_tolerance = beta_tolerance,
      agreement_tolerance = agreement_tolerance,
      tolerance = tolerance)

    ell_U <- unrestricted$logLik
    data.frame(
      b = b, seed = draw_seed, successful = TRUE,
      QLR_RRR = max(0, 2 * (ell_U - block$logLik)),
      LR_ML_oracle = max(0, 2 * (ell_U - oracle$logLik)),
      LR_ML_conventional = max(0, 2 * (ell_U - conventional$logLik)),
      ell_U = ell_U,
      ell_block = block$logLik,
      ell_ML_oracle = oracle$logLik,
      ell_ML_conventional = conventional$logLik,
      oracle_converged = oracle$converged,
      conventional_converged = conventional$converged,
      conventional_starts_agreeing = conventional$starts_agreeing,
      conventional_starts_total = conventional$starts_total,
      conventional_agreement_fraction = conventional$agreement_fraction,
      conventional_start_logLik_range = conventional$start_logLik_range,
      oracle_improves_conventional =
        oracle$logLik > conventional$logLik + agreement_tolerance,
      ordering_oracle_ok = ell_U + tolerance >= oracle$logLik,
      ordering_conventional_ok = ell_U + tolerance >= conventional$logLik,
      error = NA_character_,
      stringsAsFactors = FALSE)
  }, error = function(e) {
    data.frame(
      b = b, seed = draw_seed, successful = FALSE,
      QLR_RRR = NA_real_, LR_ML_oracle = NA_real_,
      LR_ML_conventional = NA_real_, ell_U = NA_real_,
      ell_block = NA_real_, ell_ML_oracle = NA_real_,
      ell_ML_conventional = NA_real_, oracle_converged = FALSE,
      conventional_converged = FALSE,
      conventional_starts_agreeing = NA_integer_,
      conventional_starts_total = NA_integer_,
      conventional_agreement_fraction = NA_real_,
      conventional_start_logLik_range = NA_real_,
      oracle_improves_conventional = NA,
      ordering_oracle_ok = FALSE, ordering_conventional_ok = FALSE,
      error = conditionMessage(e), stringsAsFactors = FALSE)
  })
  ans
}

bootstrap_exact_ml_lr_vs_qlr <- function(
    Y, break_t, rank, lag_level = 2L,
    norm_rows = seq_len(rank),
    B = 999L, seed = 20260724L,
    include_intercept = TRUE,
    number_random_starts = 10L,
    observed_oracle_beta = NULL,
    maximum_iterations = 2000L,
    likelihood_tolerance = 1e-10,
    beta_tolerance = 1e-8,
    agreement_tolerance = 1e-6,
    tolerance = 1e-10,
    workers = 1L,
    progress_every = 25L,
    output_csv = NULL) {
  Y <- as.matrix(Y)
  B <- as.integer(B)

  # The block-RRR restricted fit is the rank-preserving null generator and the
  # restricted fit used by QLR_RRR.
  null_fit <- estimate_break_vecm_rrr(
    Y, break_t, rank, lag_level, norm_rows,
    include_intercept, tolerance)
  unrestricted <- estimate_separate_vecms_rrr(
    Y, break_t, rank, lag_level, norm_rows, norm_rows,
    include_intercept, tolerance)

  conventional_obs <- fit_restricted_ml_protocol(
    Y, break_t, rank, lag_level, norm_rows, include_intercept,
    protocol = "conventional",
    number_random_starts = number_random_starts, seed = seed + 11L,
    maximum_iterations = maximum_iterations,
    likelihood_tolerance = likelihood_tolerance,
    beta_tolerance = beta_tolerance,
    agreement_tolerance = agreement_tolerance,
    tolerance = tolerance)

  # In a genuine Monte Carlo experiment pass the population beta0 here.
  # For an empirical fitted-null diagnostic, leave NULL and beta_hat_R is used.
  if (is.null(observed_oracle_beta)) observed_oracle_beta <- null_fit$beta
  oracle_obs <- fit_restricted_ml_protocol(
    Y, break_t, rank, lag_level, norm_rows, include_intercept,
    protocol = "oracle", beta_oracle = observed_oracle_beta,
    seed = seed + 17L,
    maximum_iterations = maximum_iterations,
    likelihood_tolerance = likelihood_tolerance,
    beta_tolerance = beta_tolerance,
    agreement_tolerance = agreement_tolerance,
    tolerance = tolerance)

  ell_U <- unrestricted$logLik
  observed <- c(
    QLR_RRR = max(0, 2 * (ell_U - null_fit$logLik)),
    LR_ML_oracle = max(0, 2 * (ell_U - oracle_obs$logLik)),
    LR_ML_conventional = max(0, 2 * (ell_U - conventional_obs$logLik)))

  set.seed(seed)
  draw_seeds <- sample.int(.Machine$integer.max - 1000L, B)
  job <- function(b) one_paired_bootstrap_draw(
    b, draw_seeds[b], Y, null_fit, break_t, rank, lag_level, norm_rows,
    include_intercept, number_random_starts, maximum_iterations,
    likelihood_tolerance, beta_tolerance, agreement_tolerance, tolerance)

  if (workers > 1L && .Platform$OS.type != "windows") {
    draws <- parallel::mclapply(seq_len(B), job, mc.cores = workers)
  } else {
    draws <- vector("list", B)
    for (b in seq_len(B)) {
      draws[[b]] <- job(b)
      if (progress_every > 0L && b %% progress_every == 0L) {
        message("Paired bootstrap: ", b, "/", B)
      }
    }
  }
  draws <- do.call(rbind, draws)
  if (!is.null(output_csv)) write.csv(draws, output_csv, row.names = FALSE)

  qlr_cal <- bootstrap_pvalue(draws$QLR_RRR, observed["QLR_RRR"])
  oracle_cal <- bootstrap_pvalue(
    draws$LR_ML_oracle, observed["LR_ML_oracle"])
  conventional_cal <- bootstrap_pvalue(
    draws$LR_ML_conventional, observed["LR_ML_conventional"])

  valid <- draws$successful
  diagnostics <- list(
    requested = B,
    jointly_successful = sum(valid),
    joint_failure_rate = 1 - mean(valid),
    oracle_convergence_rate = mean(draws$oracle_converged[valid]),
    conventional_convergence_rate =
      mean(draws$conventional_converged[valid]),
    conventional_all_starts_agree_rate = mean(
      draws$conventional_starts_agreeing[valid] ==
        draws$conventional_starts_total[valid], na.rm = TRUE),
    conventional_mean_agreement_fraction = mean(
      draws$conventional_agreement_fraction[valid], na.rm = TRUE),
    oracle_improvement_rate = mean(
      draws$oracle_improves_conventional[valid], na.rm = TRUE),
    likelihood_ordering_failure_oracle = mean(
      !draws$ordering_oracle_ok[valid], na.rm = TRUE),
    likelihood_ordering_failure_conventional = mean(
      !draws$ordering_conventional_ok[valid], na.rm = TRUE))

  list(
    call = match.call(),
    observed = observed,
    p_values = c(
      QLR_RRR = qlr_cal$p_value,
      LR_ML_oracle = oracle_cal$p_value,
      LR_ML_conventional = conventional_cal$p_value),
    MCSE = c(
      QLR_RRR = qlr_cal$MCSE,
      LR_ML_oracle = oracle_cal$MCSE,
      LR_ML_conventional = conventional_cal$MCSE),
    critical_values = rbind(
      QLR_RRR = qlr_cal$critical_values,
      LR_ML_oracle = oracle_cal$critical_values,
      LR_ML_conventional = conventional_cal$critical_values),
    diagnostics = diagnostics,
    observed_fits = list(
      null_generator = null_fit,
      unrestricted = unrestricted,
      oracle = oracle_obs,
      conventional = conventional_obs),
    bootstrap_draws = draws,
    note = paste(
      "The oracle protocol is a computational diagnostic.",
      "Only the conventional-start protocol is operational inference.",
      "Neither result should be called certified exact ML unless optimization",
      "diagnostics support attainment of the restricted global maximum."))
}

print.ml_lr_paired_bootstrap <- function(x, ...) {
  print(cbind(
    statistic = x$observed,
    bootstrap_p = x$p_values,
    MCSE = x$MCSE))
  cat("\nOptimization diagnostics\n")
  print(x$diagnostics)
  invisible(x)
}

# Example after sourcing the two required files:
#
# ans <- bootstrap_exact_ml_lr_vs_qlr(
#   Y = Y, break_t = break_t, rank = 6, lag_level = 1,
#   norm_rows = 1:6, B = 999, number_random_starts = 10,
#   workers = 1, output_csv = "paired_bootstrap_draws.csv")
# class(ans) <- c("ml_lr_paired_bootstrap", class(ans))
# print(ans)
