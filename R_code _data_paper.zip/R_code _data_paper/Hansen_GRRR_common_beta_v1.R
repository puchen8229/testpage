# Hansen_GRRR_common_beta_v1.R
#
# Exact Gaussian maximum-likelihood estimation of a common cointegration space
# across two known regimes, specialized from Hansen's (2003) generalized
# reduced-rank regression (GRRR) algorithm.
#
# Source QLR_RRR_methods_v0_2.R before this file. The companion file supplies
# construct_vecm_matrices(), normalise_beta(), estimate_break_vecm_rrr(), and
# estimate_separate_vecms_rrr().

require_qlr_rrr_core <- function() {
  required <- c(
    "construct_vecm_matrices",
    "normalise_beta",
    "estimate_break_vecm_rrr",
    "estimate_separate_vecms_rrr"
  )
  missing <- required[!vapply(required, exists, logical(1), mode = "function")]
  if (length(missing)) {
    stop(
      "Source QLR_RRR_methods_v0_2.R first. Missing functions: ",
      paste(missing, collapse = ", ")
    )
  }
  invisible(TRUE)
}

# -----------------------------------------------------------------------------
# Conditional Gaussian ML fit for a fixed common beta
# -----------------------------------------------------------------------------

hansen_fit_given_beta <- function(data, beta,
                                  covariance = c("separate", "common"),
                                  tolerance = 1e-10) {
  covariance <- match.arg(covariance)
  beta <- as.matrix(beta)
  X0 <- data$X0
  X1 <- data$X1
  Z <- data$Z
  regime <- data$regime
  K <- data$K
  r <- ncol(beta)
  p <- data$lag_level
  fits <- vector("list", 2L)

  for (s in 1:2) {
    index <- which(regime == s)
    X0_s <- X0[index, , drop = FALSE]
    X1_s <- X1[index, , drop = FALSE]
    Z_s <- Z[index, , drop = FALSE]
    EC_s <- X1_s %*% beta
    design <- cbind(EC_s, Z_s)
    coefficients <- qr.solve(design, X0_s, tol = tolerance)
    residuals <- X0_s - design %*% coefficients

    alpha <- t(coefficients[seq_len(r), , drop = FALSE])
    nuisance_coefficients <- if (ncol(Z_s)) {
      coefficients[r + seq_len(ncol(Z_s)), , drop = FALSE]
    } else {
      matrix(numeric(0), nrow = 0L, ncol = K)
    }
    nuisance_fitted <- if (ncol(Z_s)) {
      Z_s %*% nuisance_coefficients
    } else {
      matrix(0, nrow = nrow(X0_s), ncol = K)
    }
    residualized_response <- X0_s - nuisance_fitted

    fits[[s]] <- list(
      regime = s,
      index = index,
      equation_times = data$equation_times[index],
      nobs = length(index),
      X0 = X0_s,
      X1 = X1_s,
      Z = Z_s,
      coefficients = coefficients,
      alpha = alpha,
      nuisance_coefficients = nuisance_coefficients,
      residualized_response = residualized_response,
      residuals = residuals
    )
  }

  if (covariance == "separate") {
    for (s in 1:2) {
      E_s <- fits[[s]]$residuals
      fits[[s]]$Omega <- crossprod(E_s) / nrow(E_s)
    }
  } else {
    E <- rbind(fits[[1]]$residuals, fits[[2]]$residuals)
    Omega <- crossprod(E) / nrow(E)
    fits[[1]]$Omega <- Omega
    fits[[2]]$Omega <- Omega
  }

  log_likelihood <- 0
  for (s in 1:2) {
    Omega_s <- (fits[[s]]$Omega + t(fits[[s]]$Omega)) / 2
    logdet <- determinant(Omega_s, logarithm = TRUE)
    if (logdet$sign <= 0 || !is.finite(as.numeric(logdet$modulus))) {
      stop("A fitted covariance matrix is not positive definite.")
    }
    fits[[s]]$Omega <- Omega_s
    log_likelihood <- log_likelihood - 0.5 * fits[[s]]$nobs *
      (K * (1 + log(2 * pi)) + as.numeric(logdet$modulus))
  }

  # Recover short-run matrices and intercepts for reporting.
  for (s in 1:2) {
    C <- fits[[s]]$nuisance_coefficients
    Gamma <- vector("list", max(p - 1L, 0L))
    if (p > 1L) {
      for (j in seq_len(p - 1L)) {
        rows_j <- ((j - 1L) * K + 1L):(j * K)
        Gamma[[j]] <- t(C[rows_j, , drop = FALSE])
      }
    }
    intercept <- if (data$include_intercept) {
      drop(C[nrow(C), ])
    } else {
      rep(0, K)
    }
    fits[[s]]$Gamma <- Gamma
    fits[[s]]$intercept <- intercept
  }

  list(beta = beta, fits = fits, logLik = log_likelihood,
       covariance = covariance)
}

# -----------------------------------------------------------------------------
# Hansen conditional GLS update of the normalized common beta
# -----------------------------------------------------------------------------

hansen_update_beta <- function(conditional_fit, norm_rows,
                               tolerance = 1e-10) {
  beta_old <- conditional_fit$beta
  K <- nrow(beta_old)
  r <- ncol(beta_old)
  other_rows <- setdiff(seq_len(K), norm_rows)
  index_matrix <- matrix(seq_len(K * r), nrow = K, ncol = r)
  free_index <- as.vector(index_matrix[other_rows, , drop = FALSE])

  beta_fixed <- matrix(0, nrow = K, ncol = r)
  beta_fixed[norm_rows, ] <- diag(r)
  h <- as.vector(beta_fixed)

  Q <- matrix(0, nrow = K * r, ncol = K * r)
  g <- rep(0, K * r)

  for (s in 1:2) {
    fit_s <- conditional_fit$fits[[s]]
    X <- fit_s$X1
    E0 <- fit_s$residualized_response
    alpha <- fit_s$alpha
    Omega_inverse_alpha <- solve(fit_s$Omega, alpha)
    H_s <- crossprod(alpha, Omega_inverse_alpha)
    M_s <- crossprod(X)
    right_s <- crossprod(X, E0) %*% Omega_inverse_alpha

    # vec(M_s beta H_s) = (H_s' tensor M_s) vec(beta).
    Q <- Q + kronecker(t(H_s), M_s)
    g <- g + as.vector(right_s)
  }

  Q <- (Q + t(Q)) / 2
  Q_ff <- Q[free_index, free_index, drop = FALSE]
  rhs_f <- g[free_index] - Q[free_index, , drop = FALSE] %*% h
  theta <- tryCatch(
    qr.solve(Q_ff, rhs_f, tol = tolerance),
    error = function(e) NULL
  )
  if (is.null(theta) || any(!is.finite(theta))) {
    stop("The conditional common-beta GLS update is numerically singular.")
  }

  beta_vector <- h
  beta_vector[free_index] <- drop(theta)
  beta_new <- matrix(beta_vector, nrow = K, ncol = r)
  beta_new
}

# -----------------------------------------------------------------------------
# One monotone GRRR run from one starting space
# -----------------------------------------------------------------------------

hansen_grrr_one_start <- function(data, beta_start, norm_rows,
                                  covariance = c("separate", "common"),
                                  maximum_iterations = 1000,
                                  likelihood_tolerance = 1e-10,
                                  beta_tolerance = 1e-8,
                                  monotonicity_tolerance = 1e-7,
                                  tolerance = 1e-10) {
  covariance <- match.arg(covariance)
  beta_current <- normalise_beta(beta_start, norm_rows)
  fit_current <- hansen_fit_given_beta(
    data, beta_current, covariance, tolerance)
  history <- data.frame(
    iteration = 0L,
    logLik = fit_current$logLik,
    increment = NA_real_,
    maximum_beta_change = NA_real_
  )
  converged <- FALSE
  status <- "maximum_iterations"

  for (iteration in seq_len(maximum_iterations)) {
    beta_candidate <- hansen_update_beta(
      fit_current, norm_rows, tolerance)
    fit_candidate <- hansen_fit_given_beta(
      data, beta_candidate, covariance, tolerance)
    increment <- fit_candidate$logLik - fit_current$logLik
    beta_change <- max(abs(beta_candidate - beta_current))

    history <- rbind(
      history,
      data.frame(iteration = iteration,
                 logLik = fit_candidate$logLik,
                 increment = increment,
                 maximum_beta_change = beta_change)
    )

    if (increment < -monotonicity_tolerance *
        (1 + abs(fit_current$logLik))) {
      status <- "monotonicity_failure"
      break
    }

    beta_current <- beta_candidate
    fit_current <- fit_candidate
    likelihood_small <- abs(increment) <= likelihood_tolerance *
      (1 + abs(fit_current$logLik))
    beta_small <- beta_change <= beta_tolerance
    if (likelihood_small && beta_small) {
      converged <- TRUE
      status <- "converged"
      break
    }
  }

  list(beta = fit_current$beta,
       fit = fit_current,
       logLik = fit_current$logLik,
       converged = converged,
       status = status,
       iterations = nrow(history) - 1L,
       history = history)
}

# -----------------------------------------------------------------------------
# Multi-start Hansen GRRR estimator
# -----------------------------------------------------------------------------

estimate_common_beta_hansen_grrr <- function(
    Y, break_t, rank, lag_level = 2,
    norm_rows = seq_len(rank),
    include_intercept = TRUE,
    covariance = c("separate", "common"),
    beta_starts = NULL,
    include_block_rrr_start = TRUE,
    include_zero_chart_start = TRUE,
    number_random_starts = 10,
    random_scales = c(0.25, 0.75, 1.50),
    seed = 20260716,
    maximum_iterations = 1000,
    likelihood_tolerance = 1e-10,
    beta_tolerance = 1e-8,
    monotonicity_tolerance = 1e-7,
    agreement_tolerance = 1e-6,
    tolerance = 1e-10) {
  require_qlr_rrr_core()
  covariance <- match.arg(covariance)
  Y <- as.matrix(Y)
  K <- ncol(Y)
  r <- as.integer(rank)
  if (r < 1L || r >= K) stop("rank must satisfy 0 < rank < K.")
  if (length(norm_rows) != r || length(unique(norm_rows)) != r) {
    stop("norm_rows must contain r distinct row numbers.")
  }
  data <- construct_vecm_matrices(
    Y, break_t, lag_level, include_intercept)

  starts <- list()
  labels <- character(0)
  block_fit <- NULL
  if (include_block_rrr_start) {
    block_fit <- estimate_break_vecm_rrr(
      Y, break_t, r, lag_level, norm_rows,
      include_intercept, tolerance)
    starts[[length(starts) + 1L]] <- block_fit$beta
    labels <- c(labels, "block_RRR")
  }

  if (!is.null(beta_starts)) {
    if (is.matrix(beta_starts)) beta_starts <- list(beta_starts)
    if (!is.list(beta_starts)) stop("beta_starts must be a matrix or list.")
    for (j in seq_along(beta_starts)) {
      starts[[length(starts) + 1L]] <- beta_starts[[j]]
      labels <- c(labels, paste0("user_", j))
    }
  }

  if (include_zero_chart_start) {
    beta_zero <- matrix(0, K, r)
    beta_zero[norm_rows, ] <- diag(r)
    starts[[length(starts) + 1L]] <- beta_zero
    labels <- c(labels, "zero_chart")
  }

  center <- if (!is.null(block_fit)) {
    block_fit$beta
  } else if (length(starts)) {
    normalise_beta(starts[[1L]], norm_rows)
  } else {
    beta_zero <- matrix(0, K, r)
    beta_zero[norm_rows, ] <- diag(r)
    beta_zero
  }
  other_rows <- setdiff(seq_len(K), norm_rows)
  set.seed(seed)
  if (number_random_starts > 0L) {
    for (j in seq_len(number_random_starts)) {
      scale_j <- random_scales[(j - 1L) %% length(random_scales) + 1L]
      beta_random <- center
      beta_random[other_rows, ] <- center[other_rows, , drop = FALSE] +
        matrix(rnorm((K - r) * r, sd = scale_j), nrow = K - r, ncol = r)
      starts[[length(starts) + 1L]] <- beta_random
      labels <- c(labels, paste0("random_", j, "_sd", scale_j))
    }
  }
  if (!length(starts)) stop("At least one starting value is required.")

  runs <- vector("list", length(starts))
  for (j in seq_along(starts)) {
    runs[[j]] <- tryCatch(
      hansen_grrr_one_start(
        data = data,
        beta_start = starts[[j]],
        norm_rows = norm_rows,
        covariance = covariance,
        maximum_iterations = maximum_iterations,
        likelihood_tolerance = likelihood_tolerance,
        beta_tolerance = beta_tolerance,
        monotonicity_tolerance = monotonicity_tolerance,
        tolerance = tolerance
      ),
      error = function(e) list(
        beta = NULL, fit = NULL, logLik = -Inf,
        converged = FALSE, status = paste0("error: ", conditionMessage(e)),
        iterations = NA_integer_, history = NULL
      )
    )
  }

  log_likelihoods <- vapply(runs, `[[`, numeric(1), "logLik")
  if (!any(is.finite(log_likelihoods))) stop("Every GRRR start failed.")
  best_index <- which.max(log_likelihoods)
  best <- runs[[best_index]]
  start_summary <- data.frame(
    start = seq_along(starts),
    label = labels,
    logLik = log_likelihoods,
    distance_from_best = max(log_likelihoods) - log_likelihoods,
    converged = vapply(runs, `[[`, logical(1), "converged"),
    status = vapply(runs, `[[`, character(1), "status"),
    iterations = vapply(runs, function(x) x$iterations, integer(1)),
    stringsAsFactors = FALSE
  )
  number_agreeing <- sum(
    is.finite(log_likelihoods) &
      abs(log_likelihoods - max(log_likelihoods)) <= agreement_tolerance
  )

  fit_1 <- best$fit$fits[[1L]]
  fit_2 <- best$fit$fits[[2L]]
  result <- list(
    beta = best$beta,
    alpha_1 = fit_1$alpha,
    alpha_2 = fit_2$alpha,
    Gamma_1 = fit_1$Gamma,
    Gamma_2 = fit_2$Gamma,
    intercept_1 = fit_1$intercept,
    intercept_2 = fit_2$intercept,
    Omega_1 = fit_1$Omega,
    Omega_2 = fit_2$Omega,
    residuals_1 = fit_1$residuals,
    residuals_2 = fit_2$residuals,
    logLik = best$logLik,
    converged = best$converged,
    status = best$status,
    iterations = best$iterations,
    best_start = best_index,
    best_start_label = labels[best_index],
    number_starts = length(starts),
    number_agreeing = number_agreeing,
    start_summary = start_summary,
    runs = runs,
    block_fit = block_fit,
    data = data,
    break_t = break_t,
    rank = r,
    lag_level = lag_level,
    norm_rows = norm_rows,
    covariance = covariance,
    include_intercept = include_intercept,
    method = "Hansen (2003) two-regime GRRR maximum likelihood"
  )
  class(result) <- "hansen_common_beta_grrr"
  result
}

logLik.hansen_common_beta_grrr <- function(object, ...) {
  structure(object$logLik, class = "logLik",
            nobs = length(object$data$equation_times))
}

print.hansen_common_beta_grrr <- function(x, ...) {
  cat("Hansen (2003) common-beta GRRR maximum likelihood\n")
  cat("Log likelihood: ", format(x$logLik, digits = 10), "\n", sep = "")
  cat("Best start: ", x$best_start_label, "\n", sep = "")
  cat("Converged: ", x$converged, " (", x$status, ")\n", sep = "")
  cat("Iterations: ", x$iterations, "\n", sep = "")
  cat("Starts agreeing with best: ", x$number_agreeing,
      "/", x$number_starts, "\n", sep = "")
  invisible(x)
}

# -----------------------------------------------------------------------------
# Exact Hansen LR versus block-RRR QLR for one sample
# -----------------------------------------------------------------------------

compare_hansen_lr_and_qlr <- function(
    Y, break_t, rank, lag_level = 2,
    norm_rows = seq_len(rank),
    include_intercept = TRUE,
    covariance = c("separate", "common"),
    beta_starts = NULL,
    number_random_starts = 10,
    seed = 20260716,
    tolerance = 1e-10) {
  require_qlr_rrr_core()
  covariance <- match.arg(covariance)
  if (covariance != "separate") {
    stop("The current separate-RRR benchmark uses regime-specific covariances.")
  }
  block_fit <- estimate_break_vecm_rrr(
    Y, break_t, rank, lag_level, norm_rows,
    include_intercept, tolerance)
  hansen_fit <- estimate_common_beta_hansen_grrr(
    Y = Y, break_t = break_t, rank = rank,
    lag_level = lag_level, norm_rows = norm_rows,
    include_intercept = include_intercept,
    covariance = covariance,
    beta_starts = beta_starts,
    include_block_rrr_start = TRUE,
    number_random_starts = number_random_starts,
    seed = seed,
    tolerance = tolerance)
  separate_fit <- estimate_separate_vecms_rrr(
    Y, break_t, rank, lag_level, norm_rows, norm_rows,
    include_intercept, tolerance)

  ell_U <- separate_fit$logLik
  ell_H <- hansen_fit$logLik
  ell_RRR <- block_fit$logLik
  LR_Hansen <- 2 * (ell_U - ell_H)
  QLR_RRR <- 2 * (ell_U - ell_RRR)
  approximation_gap <- 2 * (ell_H - ell_RRR)
  df <- rank * (ncol(as.matrix(Y)) - rank)

  list(
    LR_Hansen = LR_Hansen,
    QLR_RRR = QLR_RRR,
    approximation_gap = approximation_gap,
    decomposition_error = QLR_RRR - LR_Hansen - approximation_gap,
    formal_df = df,
    Hansen_chi_square_p_value = pchisq(LR_Hansen, df = df, lower.tail = FALSE),
    logLik_unrestricted = ell_U,
    logLik_Hansen_restricted = ell_H,
    logLik_block_RRR = ell_RRR,
    hansen_fit = hansen_fit,
    block_fit = block_fit,
    separate_fit = separate_fit
  )
}

# -----------------------------------------------------------------------------
# Seven-variable, rank-two DGP used in the attached simulation
# -----------------------------------------------------------------------------

dgp_K7_r2_common_beta <- function(T = 300, break_t = 151,
                                  burn_in = 0L, seed = 12345) {
  set.seed(seed)
  K <- 7L
  r <- 2L
  beta <- matrix(c(
    1, 0, -1, 0, 0, 1, 0, -1, 0, 0, 0, 0, 0, 0
  ), nrow = K, ncol = r, byrow = TRUE)
  alpha_1 <- matrix(c(
    -0.18, 0, 0.10, 0, 0, -0.14, 0, 0.09,
    -0.03, 0.02, 0.02, -0.02, 0.01, 0.01
  ), nrow = K, ncol = r, byrow = TRUE)
  alpha_2 <- matrix(c(
    -0.06, 0.02, 0.04, -0.01, 0.01, -0.25, -0.01, 0.08,
    -0.05, 0.03, 0.03, -0.04, 0.02, 0.02
  ), nrow = K, ncol = r, byrow = TRUE)
  Gamma_1 <- diag(c(0.18, 0.12, 0.16, 0.10, 0.14, 0.08, 0.12))
  Gamma_1[1, 3] <- 0.04
  Gamma_1[3, 1] <- -0.03
  Gamma_1[5, 6] <- 0.05
  Gamma_1[6, 5] <- -0.04
  Gamma_2 <- diag(c(-0.05, 0.20, 0.05, 0.18, 0.22, 0.10, -0.02))
  Gamma_2[1, 3] <- -0.06
  Gamma_2[3, 1] <- 0.05
  Gamma_2[5, 6] <- -0.05
  Gamma_2[6, 5] <- 0.04
  innovation_sd <- c(0.12, 0.10, 0.11, 0.08, 0.08, 0.15, 0.13)
  correlation <- matrix(0.20, K, K)
  diag(correlation) <- 1
  Sigma <- diag(innovation_sd) %*% correlation %*% diag(innovation_sd)
  Sigma_chol <- chol(Sigma)

  total_T <- T + burn_in
  break_total <- burn_in + break_t
  Y <- matrix(0, total_T, K)
  dY <- matrix(0, total_T, K)
  Y[1, ] <- rnorm(K, sd = 0.20)
  for (t in 2:total_T) {
    regime_2 <- t >= break_total
    alpha_t <- if (regime_2) alpha_2 else alpha_1
    Gamma_t <- if (regime_2) Gamma_2 else Gamma_1
    ect_lag <- drop(crossprod(beta, Y[t - 1L, ]))
    epsilon_t <- drop(t(Sigma_chol) %*% rnorm(K))
    dY[t, ] <- drop(alpha_t %*% ect_lag +
                      Gamma_t %*% dY[t - 1L, ] + epsilon_t)
    Y[t, ] <- Y[t - 1L, ] + dY[t, ]
  }
  keep <- (burn_in + 1L):(burn_in + T)
  Y <- Y[keep, , drop = FALSE]
  dY <- dY[keep, , drop = FALSE]
  colnames(Y) <- paste0("Y", seq_len(K))
  colnames(dY) <- paste0("dY", seq_len(K))
  list(Y = Y, dY = dY, beta = beta,
       alpha_1 = alpha_1, alpha_2 = alpha_2,
       Gamma_1 = Gamma_1, Gamma_2 = Gamma_2,
       Sigma = Sigma, break_t = break_t, rank = r,
       K = K, burn_in = burn_in)
}

# -----------------------------------------------------------------------------
# Monte Carlo runner for Hansen LR, QLR_RRR, and optimization diagnostics
# -----------------------------------------------------------------------------

run_hansen_common_beta_mc <- function(
    R = 100, T = 300, break_t = floor(T / 2) + 1L,
    burn_in = 0L, lag_level = 2,
    include_intercept = TRUE,
    number_random_starts = 10,
    include_true_beta_start = TRUE,
    seed = 20260716,
    progress_every = 10,
    output_csv = NULL,
    tolerance = 1e-10) {
  require_qlr_rrr_core()
  set.seed(seed)
  replication_seeds <- sample.int(.Machine$integer.max, R, replace = FALSE)
  results <- data.frame(
    replication = seq_len(R),
    seed = replication_seeds,
    LR_Hansen = NA_real_,
    QLR_RRR = NA_real_,
    approximation_gap = NA_real_,
    ell_U = NA_real_,
    ell_Hansen = NA_real_,
    ell_block_RRR = NA_real_,
    ell_true_beta = NA_real_,
    gain_over_true_beta = NA_real_,
    gain_over_block_RRR = NA_real_,
    Hansen_converged = FALSE,
    best_start = NA_character_,
    starts_agreeing = NA_integer_,
    starts_total = NA_integer_,
    successful = FALSE,
    error_message = NA_character_,
    stringsAsFactors = FALSE
  )

  for (b in seq_len(R)) {
    one <- tryCatch({
      simulation <- dgp_K7_r2_common_beta(
        T = T, break_t = break_t, burn_in = burn_in,
        seed = replication_seeds[b])
      user_starts <- if (include_true_beta_start) list(simulation$beta) else NULL
      comparison <- compare_hansen_lr_and_qlr(
        Y = simulation$Y,
        break_t = break_t,
        rank = 2,
        lag_level = lag_level,
        norm_rows = c(1, 3),
        include_intercept = include_intercept,
        covariance = "separate",
        beta_starts = user_starts,
        number_random_starts = number_random_starts,
        seed = replication_seeds[b] + 1L,
        tolerance = tolerance)
      true_beta_fit <- hansen_fit_given_beta(
        comparison$hansen_fit$data,
        normalise_beta(simulation$beta, c(1, 3)),
        covariance = "separate",
        tolerance = tolerance)
      list(
        successful = TRUE,
        LR_Hansen = comparison$LR_Hansen,
        QLR_RRR = comparison$QLR_RRR,
        approximation_gap = comparison$approximation_gap,
        ell_U = comparison$logLik_unrestricted,
        ell_Hansen = comparison$logLik_Hansen_restricted,
        ell_block_RRR = comparison$logLik_block_RRR,
        ell_true_beta = true_beta_fit$logLik,
        gain_over_true_beta = comparison$logLik_Hansen_restricted - true_beta_fit$logLik,
        gain_over_block_RRR = comparison$logLik_Hansen_restricted -
          comparison$logLik_block_RRR,
        Hansen_converged = comparison$hansen_fit$converged,
        best_start = comparison$hansen_fit$best_start_label,
        starts_agreeing = comparison$hansen_fit$number_agreeing,
        starts_total = comparison$hansen_fit$number_starts,
        error_message = NA_character_
      )
    }, error = function(e) list(successful = FALSE,
                                error_message = conditionMessage(e)))

    fields <- intersect(names(one), names(results))
    for (field in fields) results[b, field] <- one[[field]]
    if (progress_every > 0L && (b %% progress_every == 0L || b == R)) {
      message(sprintf("Hansen MC: %d/%d completed; %d successful.",
                      b, R, sum(results$successful[seq_len(b)])))
    }
  }

  valid <- results[results$successful & is.finite(results$LR_Hansen), ]
  if (nrow(valid) < 10L) stop("Too few successful replications.")
  df <- 2L * (7L - 2L)
  summarize_statistic <- function(x) {
    c(mean = mean(x), variance = var(x), median = median(x),
      q90 = unname(quantile(x, 0.90)),
      q95 = unname(quantile(x, 0.95)),
      q99 = unname(quantile(x, 0.99)),
      rejection_10pct = mean(x > qchisq(0.90, df)),
      rejection_5pct = mean(x > qchisq(0.95, df)),
      rejection_1pct = mean(x > qchisq(0.99, df)))
  }
  summary <- rbind(
    Hansen_LR = summarize_statistic(valid$LR_Hansen),
    QLR_RRR = summarize_statistic(valid$QLR_RRR),
    chi_square_10 = c(mean = df, variance = 2 * df,
                      median = qchisq(0.50, df), q90 = qchisq(0.90, df),
                      q95 = qchisq(0.95, df), q99 = qchisq(0.99, df),
                      rejection_10pct = 0.10, rejection_5pct = 0.05,
                      rejection_1pct = 0.01)
  )

  diagnostics <- c(
    successful = nrow(valid),
    failed = R - nrow(valid),
    Hansen_convergence_rate = mean(valid$Hansen_converged),
    mean_starts_agreeing = mean(valid$starts_agreeing),
    minimum_gain_over_true_beta = min(valid$gain_over_true_beta),
    minimum_gain_over_block_RRR = min(valid$gain_over_block_RRR),
    mean_approximation_gap = mean(valid$approximation_gap)
  )
  if (!is.null(output_csv)) write.csv(results, output_csv, row.names = FALSE)

  list(results = results, valid_results = valid,
       summary = summary, diagnostics = diagnostics,
       settings = list(R = R, T = T, break_t = break_t,
                       burn_in = burn_in, df = df,
                       number_random_starts = number_random_starts,
                       include_true_beta_start = include_true_beta_start,
                       seed = seed))
}

# -----------------------------------------------------------------------------
# Recommended smoke tests (run locally; not executed when sourced)
# -----------------------------------------------------------------------------

# source("QLR_RRR_methods_v0_2.R")
# source("Hansen_GRRR_common_beta_v1.R")
#
# sim <- dgp_K7_r2_common_beta(T = 300, break_t = 151, seed = 124)
# one <- compare_hansen_lr_and_qlr(
#   Y = sim$Y, break_t = 151, rank = 2, lag_level = 2,
#   norm_rows = c(1, 3), include_intercept = TRUE,
#   beta_starts = list(sim$beta), number_random_starts = 10)
# one$LR_Hansen
# one$QLR_RRR
# one$approximation_gap
# one$hansen_fit$start_summary
#
# mc <- run_hansen_common_beta_mc(
#   R = 100, T = 300, break_t = 151,
#   number_random_starts = 10,
#   include_true_beta_start = TRUE,
#   output_csv = "Hansen_common_beta_MC_T300_R100.csv")
# mc$summary
# mc$diagnostics
