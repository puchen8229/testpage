# Updated Hansen--Seo-style term-structure illustration for QLR_RRR
#
# Main design:
#   monthly US zero-coupon Treasury yields at 1, 5, and 10 years;
#   1985M1--2025M12; known break at 2008M12;
#   K = 3, maintained cointegration rank r = 2.
#
# Data source:
#   Board of Governors of the Federal Reserve System,
#   Gürkaynak--Sack--Wright nominal yield-curve estimates.
#   https://www.federalreserve.gov/data/yield-curve-tables/feds200628.csv
#
# The script expects R_functions_for_Chatgpt.R to contain
# estimate_break_vecm_rrr(), estimate_separate_vecms_rrr(), and, for the
# optional exact-ML comparison, estimate_common_beta_vecm().

options(stringsAsFactors = FALSE)

FED_URL <- paste0(
  "https://www.federalreserve.gov/data/yield-curve-tables/",
  "feds200628.csv"
)

`%||%` <- function(x, y) if (is.null(x)) y else x

find_method_file <- function() {
  candidates <- c(
    "R_functions_for_Chatgpt.R",
    file.path("upload", "R_functions_for_Chatgpt.R"),
    file.path("..", "upload", "R_functions_for_Chatgpt.R")
  )
  hit <- candidates[file.exists(candidates)]
  if (!length(hit)) {
    stop("Could not find R_functions_for_Chatgpt.R; set method_file explicitly.")
  }
  hit[1L]
}

load_common_space_methods <- function(method_file = find_method_file()) {
  # Some early versions of R_functions_for_Chatgpt.R contain an unguarded
  # example beginning with `fit_separate <- estimate_separate_vecms(...)` at
  # the end of the file.  Ordinary source() executes that example and may fail
  # because it relies on an old object named `sim`.  Import the definitions but
  # deliberately remove that legacy execution block.
  method_lines <- readLines(method_file, warn = FALSE)
  legacy_example <- grep(
    "^[[:space:]]*fit_separate[[:space:]]*<-[[:space:]]*estimate_separate_vecms\\(",
    method_lines
  )
  if (length(legacy_example)) {
    method_lines <- method_lines[seq_len(legacy_example[1L] - 1L)]
    message("Skipped the unguarded legacy example at the end of ", method_file)
  }
  eval(parse(text = method_lines, keep.source = FALSE), envir = .GlobalEnv)

  # The uploaded combined method file calls estimate_one_vecm_rrr() from
  # estimate_separate_vecms_rrr(), but some versions accidentally omit its
  # definition.  Install the intended Johansen-RRR helper when necessary.
  if (!exists("estimate_one_vecm_rrr", mode = "function", inherits = TRUE)) {
    estimate_one_vecm_rrr <- function(
        X0, X1, Z, equation_times, rank, lag_level = 2,
        norm_rows = seq_len(rank), include_intercept = TRUE,
        tolerance = 1e-10) {
      X0 <- as.matrix(X0); X1 <- as.matrix(X1); Z <- as.matrix(Z)
      K <- ncol(X0); r <- as.integer(rank); p <- as.integer(lag_level)
      R0 <- residualise(X0, Z)
      R1 <- residualise(X1, Z)
      rrr <- rrr_beta(R0, R1, r, norm_rows, tolerance)
      beta <- rrr$beta
      X <- cbind(X1 %*% beta, Z)
      coefficients <- qr.solve(X, X0, tol = tolerance)
      residuals <- X0 - X %*% coefficients
      likelihood <- gaussian_loglik(residuals)
      alpha <- t(coefficients[seq_len(r), , drop = FALSE])

      Gamma <- vector("list", max(p - 1L, 0L))
      if (p > 1L) {
        for (j in seq_len(p - 1L)) {
          rows_j <- r + ((j - 1L) * K + 1L):(j * K)
          Gamma[[j]] <- t(coefficients[rows_j, , drop = FALSE])
        }
      }
      intercept <- if (include_intercept) {
        drop(coefficients[nrow(coefficients), ])
      } else rep(0, K)

      list(
        equation_times = equation_times, nobs = nrow(X0), beta = beta,
        alpha = alpha, Gamma = Gamma, intercept = intercept,
        Omega = likelihood$Omega, residuals = residuals,
        logLik = likelihood$logLik, rrr = rrr
      )
    }
    assign("estimate_one_vecm_rrr", estimate_one_vecm_rrr,
           envir = .GlobalEnv)
    message("Installed the missing estimate_one_vecm_rrr() helper.")
  }
  needed <- c("estimate_break_vecm_rrr", "estimate_separate_vecms_rrr")
  absent <- needed[!vapply(needed, exists, logical(1), mode = "function")]
  if (length(absent)) stop("Missing functions: ", paste(absent, collapse = ", "))
  invisible(normalizePath(method_file))
}

load_hansen_grrr <- function(hansen_file = NULL) {
  if (exists("estimate_common_beta_hansen_grrr", mode = "function")) return(TRUE)
  candidates <- c(
    hansen_file,
    "Hansen_GRRR_common_beta_v1.R",
    file.path("output", "Hansen_GRRR_common_beta_v1.R"),
    file.path("..", "output", "Hansen_GRRR_common_beta_v1.R")
  )
  candidates <- candidates[!is.na(candidates) & nzchar(candidates)]
  hit <- candidates[file.exists(candidates)]
  if (length(hit)) source(hit[1L], local = .GlobalEnv)
  exists("estimate_common_beta_hansen_grrr", mode = "function")
}

read_fed_yield_curve <- function(url = FED_URL, cache_file = NULL) {
  if (!is.null(cache_file) && file.exists(cache_file)) {
    raw_lines <- readLines(cache_file, warn = FALSE)
  } else {
    raw_lines <- readLines(url, warn = FALSE)
    if (!is.null(cache_file)) writeLines(raw_lines, cache_file)
  }

  header <- grep('^"?Date"?,', raw_lines)[1L]
  if (is.na(header)) stop("The Date header was not found in the Federal Reserve file.")

  z <- read.csv(
    text = paste(raw_lines[header:length(raw_lines)], collapse = "\n"),
    check.names = FALSE,
    na.strings = c("NA", "", "-999.99")
  )
  z$Date <- as.Date(z$Date)

  required <- c("Date", "SVENY01", "SVENY05", "SVENY10")
  if (!all(required %in% names(z))) {
    stop("Required zero-coupon columns are absent: ",
         paste(setdiff(required, names(z)), collapse = ", "))
  }
  z[order(z$Date), required]
}

make_monthly_yields <- function(daily,
                                start = as.Date("1985-01-01"),
                                end = as.Date("2025-12-31"),
                                aggregation = c("mean", "last")) {
  aggregation <- match.arg(aggregation)
  daily <- daily[daily$Date >= start & daily$Date <= end, ]
  daily$month <- as.Date(format(daily$Date, "%Y-%m-01"))

  split_rows <- split(seq_len(nrow(daily)), daily$month)
  take_month <- function(ii) {
    x <- daily[ii, c("SVENY01", "SVENY05", "SVENY10"), drop = FALSE]
    if (aggregation == "mean") {
      ans <- vapply(x, mean, numeric(1), na.rm = TRUE)
    } else {
      jj <- tail(which(complete.cases(x)), 1L)
      ans <- if (length(jj)) unlist(x[jj, ], use.names = FALSE) else rep(NA_real_, 3L)
    }
    ans
  }

  values <- do.call(rbind, lapply(split_rows, take_month))
  out <- data.frame(
    date = as.Date(names(split_rows)),
    Y1 = values[, 1L], Y5 = values[, 2L], Y10 = values[, 3L],
    row.names = NULL
  )
  out <- out[complete.cases(out), ]

  expected <- seq(as.Date(format(start, "%Y-%m-01")),
                  as.Date(format(end, "%Y-%m-01")), by = "month")
  missing_months <- setdiff(expected, out$date)
  if (length(missing_months)) {
    warning("Missing complete months: ", paste(missing_months, collapse = ", "))
  }
  out
}

select_var_lag_bic <- function(Y, max_lag = 12L, include_intercept = TRUE) {
  Y <- as.matrix(Y)
  TT <- nrow(Y); K <- ncol(Y)
  if (TT <= max_lag + 5L) stop("Sample too short for max_lag.")
  common_times <- (max_lag + 1L):TT

  score <- vapply(seq_len(max_lag), function(p) {
    X <- do.call(cbind, lapply(seq_len(p), function(j) Y[common_times - j, ]))
    if (include_intercept) X <- cbind(X, intercept = 1)
    E <- Y[common_times, ] - X %*% qr.solve(X, Y[common_times, ])
    Omega <- crossprod(E) / nrow(E)
    ld <- determinant(Omega, logarithm = TRUE)
    if (ld$sign <= 0) return(Inf)
    nrow(E) * as.numeric(ld$modulus) + log(nrow(E)) * K * ncol(X)
  }, numeric(1))

  data.frame(lag_level = seq_len(max_lag), BIC = score,
             selected = seq_len(max_lag) == which.min(score))
}

principal_angles <- function(B1, B2) {
  Q1 <- qr.Q(qr(as.matrix(B1)))
  Q2 <- qr.Q(qr(as.matrix(B2)))
  sv <- pmin(1, pmax(0, svd(crossprod(Q1, Q2), nu = 0, nv = 0)$d))
  acos(sv) * 180 / pi
}

simulate_null_path <- function(fit, Y_initial, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  Y_initial <- as.matrix(Y_initial)
  TT <- nrow(Y_initial); K <- ncol(Y_initial)
  p <- fit$lag_level; break_t <- fit$break_t
  Ystar <- matrix(NA_real_, TT, K, dimnames = dimnames(Y_initial))
  Ystar[seq_len(p), ] <- Y_initial[seq_len(p), ]

  for (tt in (p + 1L):TT) {
    s <- if (tt < break_t) 1L else 2L
    alpha <- if (s == 1L) fit$alpha_1 else fit$alpha_2
    Gamma <- if (s == 1L) fit$Gamma_1 else fit$Gamma_2
    intercept <- if (s == 1L) fit$intercept_1 else fit$intercept_2
    Omega <- if (s == 1L) fit$Omega_1 else fit$Omega_2

    dy <- drop(intercept + alpha %*% crossprod(fit$beta, Ystar[tt - 1L, ]))
    if (p > 1L) {
      for (j in seq_len(p - 1L)) {
        previous_dy <- Ystar[tt - j, ] - Ystar[tt - j - 1L, ]
        dy <- dy + drop(Gamma[[j]] %*% previous_dy)
      }
    }
    innovation <- drop(t(chol(Omega)) %*% rnorm(K))
    Ystar[tt, ] <- Ystar[tt - 1L, ] + dy + innovation
  }
  Ystar
}

bootstrap_qlr <- function(Y, break_t, rank, lag_level, norm_rows,
                          B = 999L, seed = 20260716L,
                          include_intercept = TRUE, progress_every = 50L) {
  restricted <- estimate_break_vecm_rrr(
    Y, break_t, rank, lag_level, norm_rows, include_intercept
  )
  unrestricted <- estimate_separate_vecms_rrr(
    Y, break_t, rank, lag_level, norm_rows, norm_rows, include_intercept
  )
  observed <- max(0, 2 * (unrestricted$logLik - restricted$logLik))

  set.seed(seed)
  seeds <- sample.int(.Machine$integer.max, B)
  qlr_star <- rep(NA_real_, B)
  for (b in seq_len(B)) {
    qlr_star[b] <- tryCatch({
      Ys <- simulate_null_path(restricted, Y, seeds[b])
      rfit <- estimate_break_vecm_rrr(
        Ys, break_t, rank, lag_level, norm_rows, include_intercept
      )
      ufit <- estimate_separate_vecms_rrr(
        Ys, break_t, rank, lag_level, norm_rows, norm_rows, include_intercept
      )
      max(0, 2 * (ufit$logLik - rfit$logLik))
    }, error = function(e) NA_real_)
    if (progress_every > 0L && b %% progress_every == 0L) {
      message("QLR bootstrap: ", b, "/", B)
    }
  }
  good <- is.finite(qlr_star)
  if (sum(good) < 0.9 * B) warning("More than 10% of bootstrap fits failed.")
  pvalue <- (1 + sum(qlr_star[good] >= observed)) / (1 + sum(good))

  list(
    statistic = observed,
    p_value = pvalue,
    MCSE = sqrt(pvalue * (1 - pvalue) / sum(good)),
    critical_values = quantile(qlr_star[good], c(.90, .95, .99)),
    bootstrap_statistics = qlr_star,
    restricted = restricted,
    unrestricted = unrestricted
  )
}

fit_hansen_ml_benchmark <- function(Y, break_t, rank, lag_level, norm_rows,
                                    qml_fit = NULL, n_starts = 20L,
                                    seed = 20260716L,
                                    include_intercept = TRUE,
                                    hansen_file = NULL) {
  if (is.null(qml_fit)) {
    qml_fit <- estimate_break_vecm_rrr(
      Y, break_t, rank, lag_level, norm_rows, include_intercept
    )
  }
  unrestricted <- estimate_separate_vecms_rrr(
    Y, break_t, rank, lag_level, norm_rows, norm_rows, include_intercept
  )
  has_grrr <- load_hansen_grrr(hansen_file)
  if (has_grrr) {
    exact <- estimate_common_beta_hansen_grrr(
      Y = Y, break_t = break_t, rank = rank, lag_level = lag_level,
      norm_rows = norm_rows, include_intercept = include_intercept,
      covariance = "separate", beta_starts = list(qml_fit$beta),
      number_random_starts = n_starts, seed = seed,
      maximum_iterations = 2000, likelihood_tolerance = 1e-10,
      beta_tolerance = 1e-8, agreement_tolerance = 1e-6
    )
    convergence <- exact$converged
    agreement <- paste0(exact$number_agreeing, "/", exact$number_starts)
    method <- "Hansen (2003) multi-start GRRR"
  } else if (exists("estimate_common_beta_vecm", mode = "function")) {
    exact <- estimate_common_beta_vecm(
      Y = Y, break_t = break_t, rank = rank, lag_level = lag_level,
      norm_rows = norm_rows, beta_start = qml_fit$beta,
      covariance = "separate", include_intercept = include_intercept,
      n_starts = n_starts, seed = seed, maxit = 5000, reltol = 1e-10
    )
    convergence <- exact$convergence == 0L
    agreement <- NA_character_
    method <- "multi-start profile likelihood fallback"
  } else {
    stop("Neither Hansen GRRR nor the profile-likelihood fallback is available.")
  }
  statistic <- max(0, 2 * (unrestricted$logLik - exact$logLik))
  df <- rank * (ncol(Y) - rank)
  list(
    statistic = statistic,
    df = df,
    asymptotic_p_value = pchisq(statistic, df = df, lower.tail = FALSE),
    converged = convergence,
    starts_agreeing = agreement,
    method = method,
    exact_fit = exact,
    unrestricted = unrestricted,
    note = paste(
      "The chi-square p-value is valid only for the global restricted maximum",
      "under the maintained exact-ML regularity conditions. Bootstrap QLR is",
      "the primary inference in this illustration."
    )
  )
}

run_term_structure_example <- function(
    method_file = find_method_file(),
    cache_file = "feds200628.csv",
    output_directory = "US_Treasury_common_space_results",
    start = as.Date("1985-01-01"),
    end = as.Date("2025-12-31"),
    break_month = as.Date("2008-12-01"),
    rank = 2L,
    lag_level = NULL,
    max_lag = 12L,
    B = 999L,
    run_hansen = TRUE,
    hansen_starts = 20L,
    hansen_file = NULL,
    seed = 20260716L) {

  load_common_space_methods(method_file)
  daily <- read_fed_yield_curve(cache_file = cache_file)
  monthly <- make_monthly_yields(daily, start, end, aggregation = "mean")
  Y <- as.matrix(monthly[c("Y1", "Y5", "Y10")])
  colnames(Y) <- c("y1", "y5", "y10")
  break_t <- which(monthly$date >= break_month)[1L]
  if (is.na(break_t)) stop("Break month is outside the sample.")

  lag_table <- select_var_lag_bic(Y, max_lag)
  if (is.null(lag_level)) lag_level <- lag_table$lag_level[which.min(lag_table$BIC)]
  norm_rows <- seq_len(rank)

  dir.create(output_directory, recursive = TRUE, showWarnings = FALSE)
  write.csv(monthly, file.path(output_directory, "monthly_zero_coupon_yields.csv"),
            row.names = FALSE)
  write.csv(lag_table, file.path(output_directory, "VAR_lag_BIC.csv"), row.names = FALSE)

  qlr <- bootstrap_qlr(
    Y, break_t, rank, lag_level, norm_rows,
    B = B, seed = seed, include_intercept = TRUE
  )
  angles <- principal_angles(
    qlr$unrestricted$regime_1$beta,
    qlr$unrestricted$regime_2$beta
  )

  hansen <- if (run_hansen) {
    fit_hansen_ml_benchmark(
      Y, break_t, rank, lag_level, norm_rows,
      qml_fit = qlr$restricted, n_starts = hansen_starts, seed = seed,
      hansen_file = hansen_file
    )
  } else NULL

  summary <- data.frame(
    sample_start = as.character(min(monthly$date)),
    sample_end = as.character(max(monthly$date)),
    break_month = as.character(monthly$date[break_t]),
    observations = nrow(Y), K = ncol(Y), rank = rank,
    lag_level = lag_level,
    formal_df = rank * (ncol(Y) - rank),
    QLR_RRR = qlr$statistic,
    QLR_bootstrap_p = qlr$p_value,
    QLR_bootstrap_MCSE = qlr$MCSE,
    Hansen_ML_LR = if (is.null(hansen)) NA_real_ else hansen$statistic,
    Hansen_chisq_p = if (is.null(hansen)) NA_real_ else hansen$asymptotic_p_value,
    Hansen_converged = if (is.null(hansen)) NA else hansen$converged,
    Hansen_starts_agreeing = if (is.null(hansen)) NA_character_ else hansen$starts_agreeing,
    Hansen_method = if (is.null(hansen)) NA_character_ else hansen$method
  )
  write.csv(summary, file.path(output_directory, "test_summary.csv"), row.names = FALSE)
  write.csv(data.frame(principal_angle_degrees = angles),
            file.path(output_directory, "regime_space_angles.csv"), row.names = FALSE)
  write.csv(data.frame(QLR_star = qlr$bootstrap_statistics),
            file.path(output_directory, "QLR_bootstrap_statistics.csv"), row.names = FALSE)

  # Simple data figure without extra packages.
  pdf(file.path(output_directory, "zero_coupon_yields_and_break.pdf"), 8, 5)
  matplot(monthly$date, Y, type = "l", lty = 1, lwd = 1.2,
          col = c("#1B4F72", "#B03A2E", "#196F3D"),
          xlab = "", ylab = "Percent", main = "US zero-coupon Treasury yields")
  abline(v = monthly$date[break_t], lty = 2, lwd = 1.2)
  legend("topright", c("1 year", "5 years", "10 years", "2008M12 break"),
         col = c("#1B4F72", "#B03A2E", "#196F3D", "black"),
         lty = c(1, 1, 1, 2), bty = "n")
  dev.off()

  result <- list(
    data = monthly, Y = Y, break_t = break_t, lag_table = lag_table,
    qlr = qlr, principal_angles_degrees = angles,
    hansen = hansen, summary = summary
  )
  saveRDS(result, file.path(output_directory, "term_structure_result.rds"))
  print(summary)
  invisible(result)
}

# ---------------------------------------------------------------------------
# Main execution
# ---------------------------------------------------------------------------
# Adjust method_file if R_functions_for_Chatgpt.R is stored elsewhere.
# B = 199 is useful for a quick trial; use at least B = 999 for reported work.

if (sys.nframe() == 0L) {
  result <- run_term_structure_example(
    method_file = find_method_file(),
    B = 999L,
    run_hansen = TRUE,
    hansen_starts = 20L
  )
}

# Optional direct Hansen--Seo-style bivariate robustness exercise:
# Y_biv <- result$Y[, c("y1", "y10")]
# break_t <- result$break_t
# qlr_biv <- bootstrap_qlr(
#   Y_biv, break_t, rank = 1, lag_level = result$summary$lag_level,
#   norm_rows = 1, B = 999, seed = 20260717
# )
# hansen_biv <- fit_hansen_ml_benchmark(
#   Y_biv, break_t, rank = 1, lag_level = result$summary$lag_level,
#   norm_rows = 1, qml_fit = qlr_biv$restricted,
#   n_starts = 30, seed = 20260717
# )
