TARGETED MATCHED ML–QLR BOOTSTRAP EXPERIMENT
============================================

Purpose
-------
This program implements the targeted comparison recommended for the paper:

  (K,r) = (3,2), (5,2), (7,2), and (7,6).

For every outer Monte Carlo sample, QLR-RRR and both GRRR ML protocols use
exactly the same fitted-null bootstrap paths.

GRRR protocols
--------------
1. Oracle:
   - observed Monte Carlo sample: starts at population beta_1;
   - inner fitted-null bootstrap: starts at beta_hat_R, which is the exact
     conditional generating space.
   This protocol is an infeasible computational diagnostic.

2. Conventional:
   - block-RRR start;
   - zero-chart start;
   - user-selected number of random starts.
   This is the operational procedure.

Primary inference and numerical failures
----------------------------------------
The program does not count failed GRRR optimizations as non-rejections.
Primary ML p-values use only draws that:

  - return a finite statistic;
  - satisfy the GRRR convergence criterion;
  - satisfy restricted/unrestricted likelihood ordering;
  - for the conventional protocol, reproduce the best likelihood in at least
    minimum_agreeing_starts starts.

An ML bootstrap is declared usable only when the observed fit is certified and
at least minimum_certified_fraction of inner draws are certified. Raw
finite-draw p-values are retained separately for audit.

Null and power designs
----------------------
The default grid uses angles

  0, 0.10, 0.20, 0.35 radians.

Angle zero is the null. Positive angles rotate min(r,K-r) directions of the
regime-2 cointegration space. The output reports the principal-angle and
chordal distances. For K=7,r=6 only one direction can rotate, whereas for
K=7,r=2 two directions rotate. This deliberately distinguishes rank
orientation even though both cells have q=r(K-r)=6.

Files required in one directory
-------------------------------
  R_functions_for_Chatgpt.R
  Hansen_GRRR_common_beta_v1.R
  bootstrap_exact_ML_LR_vs_QLR_RRR.R
  run_targeted_matched_ML_QLR_bootstrap_experiment.R

Windows smoke test
------------------
setwd("C:/path/to/program")
source("run_targeted_matched_ML_QLR_bootstrap_experiment.R")

smoke_grid <- matched_default_grid(power_angles = numeric(0))
smoke <- run_targeted_matched_experiment(
  program_dir = getwd(),
  output_dir = file.path(getwd(), "targeted_matched_smoke"),
  grid = smoke_grid,
  R = 2,
  B = 9,
  number_random_starts = 1,
  minimum_agreeing_starts = 1,
  maximum_iterations = 300,
  workers = 2
)

Development run
---------------
development <- run_targeted_matched_experiment(
  program_dir = getwd(),
  output_dir = file.path(getwd(), "targeted_matched_development"),
  R = 100,
  B = 199,
  number_random_starts = 3,
  minimum_agreeing_starts = 2,
  workers = 4
)

Final run
---------
final <- run_targeted_matched_experiment(
  program_dir = getwd(),
  output_dir = file.path(getwd(), "targeted_matched_final"),
  R = 500,
  B = 399,
  number_random_starts = 10,
  minimum_agreeing_starts = 2,
  maximum_iterations = 2000,
  workers = 6
)

Computational recommendation
----------------------------
Run the smoke test first. Then run the four null cells before the power cells:

null_grid <- matched_default_grid(power_angles = numeric(0))
final_null <- run_targeted_matched_experiment(
  grid = null_grid,
  R = 500,
  B = 399,
  number_random_starts = 10
)

The complete final grid is expensive because it nests B GRRR bootstrap fits
inside each of R outer Monte Carlo replications. Checkpoint CSV files make every
cell restartable.

Principal outputs
-----------------
Each cell writes:

  *_replications.csv  one row per outer Monte Carlo sample;
  *_summary.csv       size/power and numerical-diagnostic summary.

The full run also writes:

  targeted_matched_design_grid.csv;
  targeted_matched_all_cells_summary.csv.

The summary contains:

  - bootstrap rejection rates and Monte Carlo standard errors;
  - usable ML-bootstrap fractions;
  - certified inner-draw fractions;
  - QLR/oracle/conventional decision disagreement;
  - oracle improvement over conventional starts;
  - conventional start agreement;
  - computation-time quantiles.

Note
----
The code calls the existing GRRR implementation. “Exact ML LR” describes the
Gaussian likelihood criterion, not guaranteed attainment of its global maximum.
The certification and agreement diagnostics must accompany every reported ML
result.
